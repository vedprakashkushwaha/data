# INEFTE WEB AOO:
* A React web app.

# Versions:
* Node: `12.15.0`
* React: `17.0.2`

# Steps to install:

- Install packages and dependencies `npm install`

* `npm start`: Will start running React app.
* `npm run build`: Will create build.