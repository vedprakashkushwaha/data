import appConstants from "./../config/appConstants";
import "react-toastify/dist/ReactToastify.css";
import routes from "src/routes";

export function getToken() {
  let userData = localStorage.getItem(appConstants?.loggedUserToken);
  return userData ? userData : null;
}

export function updateBreadCrumb(data, type) {
  if (data?.name && type?.includes("update")) {
    let route, breadCrumb;
    if (data.pathname != "/collectionItem") {
      // variation update
      route = localStorage.getItem("breadCrumb");
      breadCrumb = route + " / " + data.name;
      localStorage.setItem("breadCrumb", breadCrumb);
      return;
    }
    // collectionItem and variation name  update
    route = routes.filter((i) => i.path === data.pathname)[0];
    breadCrumb = route.name.split("/");
    const pathname = data.pathname.replace("/", "");

    const index = breadCrumb.findIndex(
      (i) => i.toLowerCase() === pathname.toLowerCase()
    );
    breadCrumb[index] = data.name;

    const final = breadCrumb.join(" / ");
    localStorage.setItem("breadCrumb", final);
    return;
  } else if (type?.includes("back")) {
    // back button click breadcrum
    let breadCrumb = localStorage.getItem("breadCrumb").replaceAll(" ", "");
    breadCrumb = breadCrumb.split("/");
    let final = breadCrumb.splice(0, breadCrumb.length - 1).join(" / ");

    localStorage.setItem("breadCrumb", final);
    return;
  } else {
    // simple add
    let breadCrumb = localStorage.getItem("breadCrumb").replace(" ", "");
    let final = breadCrumb + "/" + data.name;
    final = final.split("/").join(" / ");

    localStorage.setItem("breadCrumb", final);
    return;
  }
}

export function logout() {
  localStorage.removeItem("loggedUserToken");
  window.location = "/login";
}
