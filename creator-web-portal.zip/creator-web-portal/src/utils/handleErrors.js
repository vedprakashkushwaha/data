import { logout } from "../utils/utilities";
import appConstants from "../config/appConstants.json";
import { notifyError } from "../utils/notification";

export const handleErrors = (error) => {
  console.log("err: ", error);
  if (!error.response) return { message: appConstants.SERVICE_ERROR };
  else {
    if (error.response.status === 403) {
      notifyError("Duplicate Record!!");
    }
    if (error.response.status === 401) logout();
    else {
      return error.response;
    }
  }
};
