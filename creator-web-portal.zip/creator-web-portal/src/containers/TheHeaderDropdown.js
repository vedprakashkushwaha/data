import React, { useState } from "react";
import {
  CButton,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CImg,
} from "@coreui/react";
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from "reactstrap";
import CIcon from "@coreui/icons-react";
import { logOut } from "src/redux/actions";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";

const TheHeaderDropdown = ({ auth: { isAuthenticated }, logOut }) => {
  const [openModal, setOpenModal] = useState(false);

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  const logoutUser = () => {
    localStorage.removeItem("loggedUserToken");
    logOut();
  };

  const toggleModal = () => {
    setOpenModal(!openModal);
  };

  return (
    <>
      {/* // <CDropdown inNav className="c-header-nav-items mx-2" direction="down">
    //   <CDropdownToggle className="c-header-nav-link" caret={false}>
    //     <div className="c-avatar">
    //       <CImg
    //         src={"avatars/6.jpg"}
    //         className="c-avatar-img"
    //         alt="admin@bootstrapmaster.com"
    //       />
    //     </div>
    //   </CDropdownToggle>
    //   <CDropdownMenu className="pt-0" placement="bottom-end">
    //     <CDropdownItem>
    //       <CIcon name="cil-lock-locked" className="mfe-2" />
    //       <CButton className="px-4" onClick={logoutUser}>
    //         Logout
    //       </CButton>
    //     </CDropdownItem>
    //   </CDropdownMenu>
    // </CDropdown> */}

      <Modal isOpen={openModal} toggle={toggleModal} centered size="sm">
        <ModalHeader closeButton toggle={toggleModal}>
          Are you sure to Logout?
        </ModalHeader>
        <ModalFooter>
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
          <Button color="primary" onClick={logoutUser}>
            Logout
          </Button>
        </ModalFooter>
      </Modal>

      <div className="logout-btn" onClick={toggleModal}>
        <CButton className="px-4">
          <CIcon name="cil-lock-locked" className="mfe-2" />
          Logout
        </CButton>
      </div>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    auth: state.auth,
  };
};

export default connect(mapStateToProps, { logOut })(TheHeaderDropdown);
