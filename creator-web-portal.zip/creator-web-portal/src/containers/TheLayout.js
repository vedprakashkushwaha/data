import React, { useState } from "react";
import { TheContent, TheSidebar, TheFooter, TheHeader } from "./index";

const TheLayout = () => {
  const [toggleSB, setToggleSB] = useState(true);

  const toggle = () => {
    setToggleSB(!toggleSB);
  };
  // setToggleSB(!ToggleSB);

  return (
    <div className="c-app c-default-layout">
      <TheSidebar showSB={toggleSB} />
      <div className="c-wrapper">
        <TheHeader toggler={toggle} />
        <div className="c-body">
          <TheContent />
        </div>
        <TheFooter />
      </div>
    </div>
  );
};

export default TheLayout;
