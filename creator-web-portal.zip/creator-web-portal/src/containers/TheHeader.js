import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  CHeader,
  CToggler,
  CHeaderBrand,
  CHeaderNav,
  CHeaderNavItem,
  CHeaderNavLink,
  CSubheader,
  CBreadcrumbRouter,
  CButton,
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { TheHeaderDropdown } from "./index";
import { useLocation } from "react-router-dom";
import routes from "../routes";
import { updateBreadCrumb } from "src/utils/utilities";
import { useHistory } from "react-router-dom";

const TheHeader = ({ toggler }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const sidebarShow = useSelector((state) => state.sidebarShow);
  const [backBtnStatus, setBackBtnStatus] = useState(true);
  const [breadCrumbData, setBreadCrumbData] = useState(
    localStorage.getItem("breadCrumb")
  );

  // const toggleSidebar = () => {
  //   const val = [true, "responsive"].includes(sidebarShow)
  //     ? false
  //     : "responsive";
  //   dispatch({ type: "set", sidebarShow: val });
  // };

  // const toggleSidebarMobile = () => {
  //   const val = [false, "responsive"].includes(sidebarShow)
  //     ? true
  //     : "responsive";
  //   dispatch({ type: "set", sidebarShow: val });
  // };

  // function sidebarToggle() {
  //   console.log('start')
  //   setSidebarShow(!sidebarShow)
  //   // if (isSideDisplayed === "true"){
  //   // localStorage.setItem("sidebarShow", sidebarShow);
  //   //   console.log(isSideDisplayed);
  //   // }
  //   // else{
  //   //   localStorage.setItem("SideBar", 'true');
  //   //   console.log(isSideDisplayed);
  //   // }
  // }
  // useEffect(() => {
  //   localStorage.setItem("sidebarShow", sidebarShow);
  // }, [sidebarShow])

  const back = () => {
    updateBreadCrumb({}, "back");
    history.goBack();
  };

  useEffect(() => {
    if (
      location.pathname === "/collection" ||
      location.pathname.includes("drop")
    ) {
      let path = location.pathname.replace("/", "");
      path = path.charAt(0).toUpperCase() + path.slice(1);
      setBreadCrumbData(path);
      localStorage.setItem("breadCrumb", path);
      setBackBtnStatus(false);
    } else {
      let path = localStorage.getItem("breadCrumb");
      setBreadCrumbData(path);
      setBackBtnStatus(true);
    }
  });
  return (
    <CHeader withSubheader>
      <CToggler
        inHeader
        className="ml-md-3 d-lg-none"
        onClick={() => toggler()}
      />
      <CToggler
        inHeader
        className="ml-3 d-md-down-none"
        onClick={() => toggler()}
      />
      <CHeaderBrand className="mx-auto d-lg-none" to="/">
        <CIcon name="logo" height="48" alt="Logo" />
      </CHeaderBrand>
      <CHeaderNav className="d-md-down-none mr-auto">
        <CHeaderNavItem className="px-3">
          <CHeaderNavLink to="/dashboard">Dashboard</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-3">
          <CHeaderNavLink to="/users">Users</CHeaderNavLink>
        </CHeaderNavItem>
        <CHeaderNavItem className="px-3">
          <CHeaderNavLink>Settings</CHeaderNavLink>
        </CHeaderNavItem>
      </CHeaderNav>
      <CHeaderNav className="px-3">
        <TheHeaderDropdown />
      </CHeaderNav>

      <CSubheader className="px-3 justify-content-between">
        {/* <CBreadcrumbRouter
          className="border-0 c-subheader-nav m-0 px-0 px-md-3"
          routes={routes}
        /> */}
        <div className="border-0 c-subheader-nav m-0 px-0 px-md-3">
          {breadCrumbData}
        </div>
        {backBtnStatus ? (
          <CButton color="dark" className="m-1" onClick={back}>
            Back
          </CButton>
        ) : (
          <div />
        )}
      </CSubheader>
    </CHeader>
  );
};

export default TheHeader;
