import React from "react";
import blockcoimage from "src/assets/icons/images/Symbol_Green.png";
import BlockcoTextImg from "src/assets/icons/images/logo_Text_White_Green.png";

const TheUpperFooter = () => {
  return (
    <div fixed={false} className="UpperFooter">
      <div>
        <img src={blockcoimage} alt="logo" width="50px" />
      </div>
      <div>
        <img src={BlockcoTextImg} alt="BlockcoText" width="100px" />
      </div>
    </div>
  );
};

export default TheUpperFooter;
