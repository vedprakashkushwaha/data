import React from "react";
// import TheUpperFooter from "src/containers/TheUpperFooter";

const TheFooter = () => {
  return (
    <>
      <div className="footerproto">
        {/* <TheUpperFooter /> */}
        <div fixed={false} className="LowerFooter">
          <div className="footer-text-left">
            <span>&copy; 2021 BLOCK LABS.</span>
            <span className="ml-1"> ALL RIGHTS RESERVED.</span>
          </div>
          {/* <div className="follow-font">
            <span className="mr-1">FOLLOW ME ON:</span>
            <i className="socialB fa fa-facebook"></i>
            <i className="socialB fa fa-twitter"></i>
            <i className="socialB fa fa-pinterest"></i>
            <i className="socialB fa fa-instagram"></i>
          </div> */}
        </div>
      </div>
    </>
  );
};

export default React.memo(TheFooter);
