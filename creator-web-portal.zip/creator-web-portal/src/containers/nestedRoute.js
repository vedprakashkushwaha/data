import React, { Fragment } from "react";
import { TheContent, TheSidebar, TheFooter, TheHeader } from "./index";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { CContainer, CFade } from "@coreui/react";

const TheNested = (props) => {
  const loading = (
    <div className="pt-3 text-center">
      <div className="sk-spinner sk-spinner-pulse"></div>
    </div>
  );
  return (
    <Fragment>
      <BrowserRouter>
        <React.Suspense fallback={loading}>
          <Switch>
            <div className="c-app c-default-layout">
              <TheSidebar />
              <div className="c-wrapper">
                <TheHeader />
                <div className="c-body">
                  <Route
                    // key={idx}
                    path={props.path}
                    exact={props.exact}
                    name={props.name}
                    render={(props) => (
                      <CFade>
                        <props.component {...props} />
                      </CFade>
                    )}
                  />
                </div>
                <TheFooter />
              </div>
            </div>
          </Switch>
        </React.Suspense>
      </BrowserRouter>
    </Fragment>
  );
};

export default TheNested;
