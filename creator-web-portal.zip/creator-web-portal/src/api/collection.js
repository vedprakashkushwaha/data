import common from "./common";
import axios from "axios";
import { getToken } from "../utils/utilities";
import { handleErrors } from "../utils/handleErrors";

export const _createCollection = (data) => {
  var authOptions = {
    method: "POST",
    url: common.createCollection,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getCollections = () => {
  getToken();
  var authOptions = {
    method: "GET",
    url: common.getCollections,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _updateCollection = async (collectionId, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateCollection}/:${collectionId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _deleteCollection = async (data) => {
  var authOptions = {
    method: "DELETE",
    url: `${common.deleteCollection}/:${data.collectionId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _createLayer = (data) => {
  var authOptions = {
    method: "POST",
    url: common.createLayer,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getLayers = (data) => {
  var authOptions = {
    method: "GET",
    url: `${common.getLayers}?collection_id=${data.collection_id}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _deleteLayer = async (data) => {
  var authOptions = {
    method: "DELETE",
    url: `${common.deleteLayer}/:${data.layerId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _updateLayer = async (layerId, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateLayer}/:${layerId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _uploadLayerImage = async (layerId, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateLayer}/:${layerId}/image`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};
