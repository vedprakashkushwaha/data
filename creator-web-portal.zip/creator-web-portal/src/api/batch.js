import common from "./common";
import axios from "axios";
import { getToken } from "../utils/utilities";
import { handleErrors } from "../utils/handleErrors";

export const _createBatch = (data) => {
  var authOptions = {
    method: "POST",
    url: common.createBatch,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getBatches = (data) => {
  getToken();
  var authOptions = {
    method: "GET",
    url: `${common.getBatches}?collection_id=${data.collection_id}`,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _deleteBatch = async (data) => {
  var authOptions = {
    method: "DELETE",
    url: `${common.deleteBatch}/:${data.batchId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _updateBatchDetails = (batchId, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateBatchDetails}/:${batchId}/generation`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _updateBatch = async (batchId, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateBatch}/:${batchId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _getBatchImages = (data) => {
  getToken();
  var authOptions = {
    method: "GET",
    url: `${common.getBatchImages}?image_batch_id=${data.image_batch_id}&max_entries=${data.max_entries}&offset=${data.offset}`,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getBatchData = (batchId) => {
  getToken();
  var authOptions = {
    method: "GET",
    url: `${common.getBatches}/:${batchId}`,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};
