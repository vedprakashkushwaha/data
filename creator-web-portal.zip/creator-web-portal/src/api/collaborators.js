import common from "./common";
import axios from "axios";
import { getToken } from "../utils/utilities";
import { handleErrors } from "../utils/handleErrors";

export const _getCollaborators = (data) => {
  var authOptions = {
    method: "GET",
    url: `${common.getCollaborators}/:${data.collectionId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _addCollaborator = async (data) => {
  var authOptions = {
    method: "POST",
    url: common.addCollaborator,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _removeCollaborator = async (collectionId, data) => {
  var authOptions = {
    method: "DELETE",
    url: `${common.removeCollaborator}/:${collectionId}?creator_id=${data.creator_id}`,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};
