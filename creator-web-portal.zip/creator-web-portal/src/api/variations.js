import common from "./common";
import axios from "axios";
import { getToken } from "../utils/utilities";
import { handleErrors } from "../utils/handleErrors";

export const _createVariations = (data) => {
  var authOptions = {
    method: "POST",
    url: common.createVariations,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getVariations = (data) => {
  var authOptions = {
    method: "GET",
    url: `${common.getVariations}?layer_id=${data.layer_id}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _updateVariation = async (requestData, data) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.updateVariation}/:${requestData.variationId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _deleteVariation = async (data) => {
  var authOptions = {
    method: "DELETE",
    url: `${common.deleteVariation}/:${data.variationId}`,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  try {
    const response = await axios(authOptions);
    console.log("response :", response);
    return response;
  } catch (error) {
    return handleErrors(error);
  }
};

export const _uploadVariationImage = (data, requestData) => {
  var authOptions = {
    method: "PATCH",
    url: `${common.uploadVariationImage}/:${data.variationId}/image/:${data.imageType}`,
    data: requestData,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _getVariationDetails = (data) => {
  var authOptions = {
    method: "GET",
    url: `${common.getVariations}/:${data.variationId}`,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};
