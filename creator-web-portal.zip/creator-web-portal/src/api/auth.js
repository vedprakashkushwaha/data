import common from "./common";
import axios from "axios";

export const GoogleLoginApi = (data) => {
  var authOptions = {
    method: "POST",
    url: common.GoogleLogin,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      console.log("Error:", error);
    });
};
