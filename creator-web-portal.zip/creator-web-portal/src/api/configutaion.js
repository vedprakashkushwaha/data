import common from "./common";
import axios from "axios";
import { getToken } from "../utils/utilities";
import { handleErrors } from "../utils/handleErrors";

export const _submitConfiguration = (data) => {
  var authOptions = {
    method: "POST",
    url: common.submitConfiguration,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};

export const _addDropSchedule = (data) => {
  var authOptions = {
    method: "POST",
    url: common.addDropSchedule,
    data: data,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
  };
  return axios(authOptions)
    .then((response) => {
      console.log("response :", response);
      return response;
    })
    .catch((error) => {
      return handleErrors(error);
    });
};
