const REACT_APP_API_URL = "http://localhost:8000";
export const DynamicUrl = REACT_APP_API_URL;

const GoogleLogin = DynamicUrl + "/api/v1/creators";
const createCollection = DynamicUrl + "/api/v1/collections";
const getCollections = DynamicUrl + "/api/v1/collections";
const updateCollection = DynamicUrl + "/api/v1/collections";
const deleteCollection = DynamicUrl + "/api/v1/collections";
const getCollaborators = DynamicUrl + "/api/v1/collections";
const addCollaborator = DynamicUrl + "/api/v1/collections/collaborator";
const removeCollaborator = DynamicUrl + "/api/v1/collections/collaborator";
const getSearchedEmail = DynamicUrl + "/api/v1/users/search/email";
const createLayer = DynamicUrl + "/api/v1/layers";
const getLayers = DynamicUrl + "/api/v1/layers";
const deleteLayer = DynamicUrl + "/api/v1/layers";
const updateLayer = DynamicUrl + "/api/v1/layers";
const createVariations = DynamicUrl + "/api/v1/variations";
const getVariations = DynamicUrl + "/api/v1/variations";
const deleteVariation = DynamicUrl + "/api/v1/variations";
const updateVariation = DynamicUrl + "/api/v1/variations";
const uploadVariationImage = DynamicUrl + "/api/v1/variations";
const submitConfiguration = DynamicUrl + "";
const addDropSchedule = DynamicUrl + "";
const createBatch = DynamicUrl + "/api/v1/image-batches";
const getBatches = DynamicUrl + "/api/v1/image-batches";
const deleteBatch = DynamicUrl + "/api/v1/image-batches";
const updateBatchDetails = DynamicUrl + "/api/v1/image-batches";
const updateBatch = DynamicUrl + "/api/v1/image-batches";
const getBatchImages = DynamicUrl + "/api/v1/images";

export default {
  GoogleLogin: GoogleLogin,
  createCollection: createCollection,
  getCollections: getCollections,
  updateCollection: updateCollection,
  deleteCollection: deleteCollection,
  getCollaborators: getCollaborators,
  addCollaborator: addCollaborator,
  removeCollaborator: removeCollaborator,
  getSearchedEmail: getSearchedEmail,
  createLayer: createLayer,
  getLayers: getLayers,
  deleteLayer: deleteLayer,
  updateLayer: updateLayer,
  createVariations: createVariations,
  getVariations: getVariations,
  deleteVariation: deleteVariation,
  updateVariation: updateVariation,
  uploadVariationImage: uploadVariationImage,
  submitConfiguration: submitConfiguration,
  addDropSchedule: addDropSchedule,
  createBatch: createBatch,
  getBatches: getBatches,
  deleteBatch: deleteBatch,
  updateBatchDetails: updateBatchDetails,
  updateBatch: updateBatch,
  getBatchImages: getBatchImages,
};
