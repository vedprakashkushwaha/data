import React from "react";

const Dashboard = React.lazy(() => import("./views/dashboard/Dashboard"));
const Drops = React.lazy(() => import("./views/drops/Drops"));
const Collections = React.lazy(() => import("./views/collections/Collections"));
const CollectionItem = React.lazy(() =>
  import("./views/collections/CollectionItem")
);
const Layers = React.lazy(() => import("./views/collections/Layers"));
const Variations = React.lazy(() => import("./views/collections/Variations"));
const Collaborators = React.lazy(() =>
  import("./views/collections/Collaborators")
);
const VariationDetails = React.lazy(() =>
  import("./views/collections/VariationDetails")
);
const Configurations = React.lazy(() =>
  import("./views/collections/Configurations")
);
const GenerateImage = React.lazy(() =>
  import("./views/collections/GenerateImage")
);
const BatchImages = React.lazy(() => import("./views/collections/BatchImages"));

const routes = [
  { path: "/", exact: true, name: "Home" },
  { path: "/dashboard", name: "Dashboard", component: Dashboard },
  { path: "/drops", name: "Drops", component: Drops },
  { path: "/collection", name: "Collection", component: Collections },
  {
    path: "/collectionItem",
    name: "Collection/CollectionItem",
    component: CollectionItem,
  },
  {
    path: "/layers",
    name: "Collection / CollectionItem / Layers",
    component: Layers,
  },
  {
    path: "/collaborators",
    name: "Collection / Collection Item / Collaborators",
    component: Collaborators,
  },
  {
    path: "/generateImage",
    name: "Collection / Collection Item / Generate Image",
    component: GenerateImage,
  },
  {
    path: "/variations",
    name: "Collection / Collection Item / Layers / Variations",
    component: Variations,
  },
  {
    path: "/variationDetails",
    name: "Collection / Collection Item / Layers / Variations / Variation Details",
    component: VariationDetails,
  },
  {
    path: "/configurations",
    name: "Collection / Collection Item / Configurations",
    component: Configurations,
  },
  { path: "/batchImages", name: "Batch Images", component: BatchImages },
];

export default routes;
