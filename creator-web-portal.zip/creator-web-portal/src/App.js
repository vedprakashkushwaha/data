import React, { Fragment, useEffect } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import "./scss/style.scss";
import { registerSuccess, logOut } from "src/redux/actions";
import { connect } from "react-redux";
import PrivateRoute from "./utils/privateRoute";
import setAuthToken from "./utils/setAuthToken";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
import { io } from "socket.io-client";

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
);

// Containers
const TheLayout = React.lazy(() => import("./containers/TheLayout"));

// Pages
const Login = React.lazy(() => import("./views/pages/login/Login"));

const App = ({ registerSuccess, logOut, setAuthToken }) => {
  useEffect(() => {
    if (localStorage.getItem("loggedUserToken")) {
      registerSuccess();
    } else {
      logOut();
    }
  }, []);

  useEffect(async () => {
    // const socket = io("http://localhost:8001");

    // socket.on('asking_for_batch_id', () => {
    //   socket.emit("batch_id", "61b97fb9e303906f76fac350");
    //   console.log("asking_for_batch_id >>>",)
    // });

    // socket.on("progress", (progress) => {
    //   console.log("progress: ", progress)
    // })

  }, [])

  return (
    <Fragment>
      <ToastContainer />
      <BrowserRouter>
        <React.Suspense fallback={loading}>
          <Switch>
            <Route
              exact
              path="/login"
              name="Login Page"
              render={(props) => <Login {...props} />}
            />
            <PrivateRoute
              path="/"
              name="Collection"
              render={(props) => <TheLayout {...props} />}
              component={TheLayout}
            />
            <PrivateRoute
              path="/collection"
              name="Collection"
              render={(props) => <TheLayout {...props} />}
              component={TheLayout}
            />
          </Switch>
        </React.Suspense>
      </BrowserRouter>
    </Fragment>
  );
};

const mapStateToProps = (state) => {
  return {
    auth: state.auth,
  };
};

export default connect(mapStateToProps, {
  registerSuccess,
  logOut,
  setAuthToken,
})(App);
