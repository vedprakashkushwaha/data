const isInputValid = (value, setvalidstate, RegXpattern) => {
  console.log(">>>>>>>", value);
  var data = value.trim();

  if (data.length === 0) {
    setvalidstate(false);
    return false;
  } else {
    setvalidstate(true);
    return true;
  }
};

export default isInputValid;
