import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
} from "reactstrap";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import { _getCollections } from "src/api/collection";
import { _addDropSchedule } from "src/api/configutaion";
import { notifySuccess } from "../../utils/notification";

const Drops = () => {
  const [addDropStatus, setAddDropStatus] = useState(false);
  const [collections, setCollections] = useState([]);
  const [collectionId, setCollectionId] = useState("");
  const [scheduleDateTime, setScheduleDateTime] = useState("");

  const handleAddDropModal = () => {
    setAddDropStatus(true);
  };

  const closeAddDropModal = () => {
    setAddDropStatus(false);
  };

  useEffect(() => {
    getCollections();
  }, []);

  const getCollections = async () => {
    try {
      _getCollections().then(async (res) => {
        if (res && res.status === 200) {
          setCollections(res.data.data);
        } else {
          setCollections([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const onCollectionSelect = (e) => {
    setCollectionId(e.target.value);
  };

  const scheduleDateTimeChange = (ev) => {
    if (!ev.target["validity"].valid) return;
    const dt = ev.target["value"] + ":00Z";
    setScheduleDateTime(dt);
  };

  const addDropSchedule = async () => {
    try {
      let requestData = {
        collection_id: collectionId,
        scheduledDate: scheduleDateTime,
      };
      _addDropSchedule(requestData).then(async (res) => {
        console.log("response of add drop schedule:", res);
        if (res && res.status === 201) {
          notifySuccess(res.data.message);
        } else {
          console.log(res ? res.data.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Drops</b>
              </CCol>
              <CCol>
                <Button
                  className="float-right"
                  color="success"
                  onClick={() => handleAddDropModal()}
                >
                  Add Drop Schedule
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <Modal
            isOpen={addDropStatus}
            toggle={closeAddDropModal}
            centered
            size="m"
          >
            <ModalHeader toggle={closeAddDropModal}>
              Add Drop Schedule
            </ModalHeader>
            <ModalBody>
              <div className="mb-3">
                <select
                  className="dropdown-cls shadow-effect"
                  onChange={(e) => onCollectionSelect(e)}
                >
                  <span>
                    <i className="icofont icofont-caret-down"></i>
                  </span>
                  <option selected>Select Collection</option>
                  {collections
                    ? collections.map((item, index) => (
                        <>
                          <option
                            className="option"
                            value={JSON.stringify(item._id)}
                          >
                            {item.name}
                          </option>
                        </>
                      ))
                    : ""}
                </select>
                <br />
                <br />
                <input
                  type="datetime-local"
                  value={(scheduleDateTime || "").toString().substring(0, 16)}
                  onChange={scheduleDateTimeChange}
                />
              </div>
            </ModalBody>
            <ModalFooter>
              <Button color="secondary" onClick={closeAddDropModal}>
                Cancel
              </Button>
              <Button color="primary" onClick={() => addDropSchedule()}>
                Add
              </Button>
            </ModalFooter>
          </Modal>
          <CCardBody>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <CRow className="configuration-padding">
                    <CCol xs="3">Collection Name</CCol>
                    <CCol xs="3">Scheduled Date Time</CCol>
                    <CCol xs="3">Process</CCol>
                    <CCol xs="3">Progress</CCol>
                  </CRow>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Drops;
