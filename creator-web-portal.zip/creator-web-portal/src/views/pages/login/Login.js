import { CContainer, CRow, CCol } from "@coreui/react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { registerSuccess } from "src/redux/actions";
import { GoogleLogin } from "react-google-login";
import { GoogleLoginApi } from "src/api/auth";
import { TheFooter } from "src/containers";
import TheHeadernav from "src/containers/Headernav";

const Login = ({ auth: { isAuthenticated }, registerSuccess }) => {
  const REACT_APP_GOOGLE_CLIENT_ID =
    "78091942368-r6e7qsoprss6ttr95se5062d00krhg1f.apps.googleusercontent.com";

  if (isAuthenticated) {
    return <Redirect to="/home" />;
  }

  const googleSuccess = (data) => {
    console.log("login data", data);
    let requestData = {
      googleId: data.profileObj.googleId,
      idToken: data.tokenId,
    };
    GoogleLoginApi(requestData).then((res) => {
      if (res && res.status === 200) {
        localStorage.setItem("loggedUserToken", res.data.data[0].token);
        registerSuccess();
      } else {
        console.log("Error Login!");
      }
    });
  };

  const googleError = (error) => {
    console.log("Google Login Error", error);
  };

  return (
    <div className="c-app c-default-layout flex-row align-items-center login-screen">
      <TheHeadernav />
      <CContainer>
        <CRow className="justify-content-center">
          {/* <CCol md="8"> */}
          <GoogleLogin
            className="login-btn"
            clientId={REACT_APP_GOOGLE_CLIENT_ID}
            buttonText=""
            onSuccess={googleSuccess}
            onFailure={googleError}
            cookiePolicy="single_host_origin"
            icon={false}
          />
          {/* </CCol> */}
        </CRow>
      </CContainer>
      <TheFooter />
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    auth: state.auth,
  };
};

export default connect(mapStateToProps, { registerSuccess })(Login);
