import React from "react";

const Dashboard = () => {
  return (
    <>
      <p>Dashboard screen</p>
    </>
  );
};

export default Dashboard;
