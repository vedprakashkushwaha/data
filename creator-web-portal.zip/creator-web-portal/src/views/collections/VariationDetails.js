import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import { Row, Col } from "reactstrap";
import { useLocation } from "react-router-dom";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import { _getVariationDetails } from "src/api/variations";

const VariationDetails = () => {
  let location = useLocation();
  const variationId = location.state.variationId.id;
  const [variationDetails, setVariationDetails] = useState([]);

  useEffect(() => {
    getVariationDetails();
  }, []);

  const getVariationDetails = async () => {
    try {
      let requestData = {
        variationId: variationId,
      };
      _getVariationDetails(requestData).then(async (res) => {
        if (res && res.status === 200) {
          setVariationDetails(res.data.data.variations);
        } else {
          setVariationDetails([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="10">
                <b>Variation Images</b>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  {variationDetails && variationDetails.length > 0 ? (
                    <>
                      <Row>
                        <table className="table table-striped variation-tbl">
                          <tbody>
                            <tr>
                              <td>
                                <b>Name:</b>
                              </td>
                              <td>{variationDetails[0].name}</td>
                            </tr>
                            <tr>
                              <td>
                                <b>Rarity:</b>
                              </td>
                              <td>{variationDetails[0].rarity}%</td>
                            </tr>
                            <tr>
                              <td>
                                <b>Detached Status:</b>
                              </td>
                              <td>
                                {variationDetails[0].form_nft_when_detached
                                  ? "True"
                                  : "False"}
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <b>Standalone Image:</b>
                              </td>
                              <td>
                                <img
                                  // className="card-img card-img-top"
                                  className="variation-details-img"
                                  src={
                                    variationDetails[0].images[0].image_url
                                      ? variationDetails[0].images[0].image_url
                                      : NoImage
                                  }
                                  alt=""
                                />
                              </td>
                            </tr>
                            <tr>
                              <td>
                                <b>Combined Image:</b>
                              </td>
                              <td>
                                <img
                                  className="variation-details-img"
                                  src={
                                    variationDetails[0].images[1].image_url
                                      ? variationDetails[0].images[1].image_url
                                      : NoImage
                                  }
                                  alt=""
                                />
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </Row>
                    </>
                  ) : (
                    "No Variation found"
                  )}
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default VariationDetails;
