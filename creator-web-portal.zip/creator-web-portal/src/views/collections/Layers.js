import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  Input,
  ModalFooter,
  Button,
} from "reactstrap";
import { useHistory } from "react-router-dom";
import {
  _createLayer,
  _getLayers,
  _deleteLayer,
  _updateLayer,
  _uploadLayerImage,
} from "src/api/collection";
import { notifyError, notifySuccess } from "../../utils/notification";
import { useLocation } from "react-router-dom";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import { updateBreadCrumb } from "src/utils/utilities";
import isInputValid from "src/validation/validate";
import NoContent from "src/views/extras/NoContent";

const Layers = () => {
  const history = useHistory();
  const [createLayerStatus, setCreateLayerStatus] = useState(false);
  const [selectedFile, setSelectedFile] = useState();
  const [isFilePicked, setIsFilePicked] = useState(false);
  const [layerName, setLayerName] = useState("");
  let location = useLocation();
  const _collectionId = location
    ? location.state.collectionId.collectionId
    : "";
  const [layers, setLayers] = useState([]);
  const [selectedLayerId, setSelectedLayerId] = useState("");
  const [deleteLayerStatus, setDeleteLayerStatus] = useState(false);
  const [updateLayerStatus, setUpdateLayerStatus] = useState(false);
  const [uploadImageStatus, setUploadImageStatus] = useState(false);
  const [CreateClicked, setCreateClicked] = useState(false);
  const [UpdateClicked, setUpdateClicked] = useState(false);
  const [UploadClicked, setUploadClicked] = useState(false);
  const [NameValid, setNameValid] = useState(true);
  const [UpdateNameValid, setUpdateNameValid] = useState(true);
  const [ImageValid, setImageValid] = useState(true);
  const [detachedResult, setDetachedResult] = useState("");
  const [order, setOrder] = useState("");
  const [OrderValid, setOrderValid] = useState(true);
  const [UpdateOrderValid, setUpdateOrderValid] = useState(true);
  const [DetachedValid, setDetachedValid] = useState(true);
  const [UpdateDetachedValid, setUpdateDetachedValid] = useState(true);

  const handleRoute = (item) => {
    let name = item.name;
    let id = item._id;
    updateBreadCrumb({ pathname: "/variations", name: name }, "update");

    history.push({
      pathname: "/variations",
      state: {
        layerName: { name },
        layerId: { id },
      },
    });
  };

  useEffect(() => {
    getLayers();
  }, []);

  const getLayers = async () => {
    try {
      let requestData = {
        collection_id: _collectionId,
      };
      _getLayers(requestData).then(async (res) => {
        if (res && res.status === 200) {
          setLayers(res.data.data.layers);
        } else {
          setLayers([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleCreateLayerModal = () => {
    setCreateLayerStatus(true);
    setSelectedFile("");
    setIsFilePicked(false);
  };

  const closeCreateLayerModal = () => {
    setCreateLayerStatus(false);
    setSelectedFile("");
    setIsFilePicked(false);
    setLayerName("");
    setNameValid(true);
    setOrder("");
    setDetachedResult("");
    setOrderValid(true);
    setDetachedValid(true);
  };

  const changeHandler = (event) => {
    setSelectedFile(event.target.files[0]);
    setIsFilePicked(true);
    setImageValid(true);
  };

  const createLayer = async () => {
    try {
      if (layerName === "" || detachedResult === "" || order === "") {
        notifyError("Enter Layer Name, Order and Detached Status");
        isInputValid(layerName, setNameValid);
        isInputValid(detachedResult, setDetachedValid);
        isInputValid(order, setOrderValid);
        if (order > 100 || order < 1) {
          setOrderValid(false);
        }
      } else if (order > 100 || order < 1) {
        setOrderValid(false);
      } else {
        setCreateClicked(true);
        let requestData = {
          name: layerName,
          collection_id: _collectionId,
          form_nft_when_detached: detachedResult,
          order: order,
        };
        console.log("check requestData", requestData);
        _createLayer(requestData).then(async (res) => {
          console.log("response of create layer:", res);
          if (res && res.status === 201) {
            notifySuccess(res.data.message);
            closeCreateLayerModal();
            setCreateLayerStatus(false);
            setDetachedResult("");
            getLayers();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          setCreateClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleDeleteLayer = (layerId) => {
    setSelectedLayerId(layerId);
    setDeleteLayerStatus(true);
  };

  const closeDeleteLayer = () => {
    setDeleteLayerStatus(false);
  };

  const deleteLayer = async () => {
    try {
      let requestData = {
        layerId: selectedLayerId,
      };
      _deleteLayer(requestData).then(async (res) => {
        console.log("response to delete collection:", res);
        if (res.status === 200) {
          notifySuccess(res.data.message);
          setDeleteLayerStatus(false);
          setSelectedLayerId("");
          getLayers();
        } else {
          console.log(res ? res.data.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const closeUpdateLayerModal = () => {
    setUpdateLayerStatus(false);
    setLayerName("");
    setUpdateNameValid(true);
    setOrder("");
    setDetachedResult("");
    setUpdateOrderValid(true);
    setUpdateDetachedValid(true);
  };

  const updateLayer = async () => {
    try {
      if (layerName === "" || detachedResult === "" || order === "") {
        notifyError("Enter Layer Name, Order and Detached Status");
        isInputValid(layerName, setUpdateNameValid);
        isInputValid(order, setUpdateOrderValid);
        if (order > 100 || order < 1) {
          setUpdateOrderValid(false);
        }
      } else {
        if (isInputValid(layerName, setUpdateNameValid)) {
          setUpdateClicked(true);
          let requestData = {
            name: layerName,
            form_nft_when_detached: detachedResult,
            order: order,
          };
          _updateLayer(selectedLayerId, requestData).then(async (res) => {
            console.log("response to update layer:", res);
            if (res && res.status === 200) {
              notifySuccess(res.data.message);
              setUpdateLayerStatus(false);
              setSelectedLayerId("");
              setIsFilePicked(false);
              getLayers();
            } else {
              console.log(res ? res.data.data.message : "Error!!");
            }
            setUpdateClicked(false);
          });
        }
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleUpdateLayer = (item) => {
    setSelectedLayerId(item._id);
    setUpdateLayerStatus(true);
    setLayerName(item.name ? item.name : "");
    setOrder(item.order ? item.order : "");
    setDetachedResult(item.form_nft_when_detached);
  };

  const handleUploadImage = (layerId) => {
    setSelectedLayerId(layerId);
    setUploadImageStatus(true);
  };

  const closeUploadImageModal = () => {
    setUploadImageStatus(false);
    setIsFilePicked(false);
    setSelectedFile("");
    setImageValid(true);
  };

  const uploadImages = async () => {
    try {
      if (!selectedFile) {
        notifyError("No file uploaded");
        setImageValid(false);
      } else {
        setImageValid(true);
        setUploadClicked(true);
        let requestData = new FormData();
        requestData.append("image", selectedFile);

        _uploadLayerImage(selectedLayerId, requestData).then(async (res) => {
          console.log("response of upload layer image:", res, res.status);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            setUploadImageStatus(false);
            setIsFilePicked(false);
            setSelectedFile("");
            getLayers();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          setUploadClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleRadioChange = (e) => {
    isInputValid(e.target.value, setDetachedValid);
    setDetachedResult(e.target.value);
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Layers</b>
              </CCol>
              <CCol>
                <Button
                  color="success"
                  className="float-right"
                  onClick={() => handleCreateLayerModal()}
                >
                  Add Layer
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={createLayerStatus}
              toggle={closeCreateLayerModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeCreateLayerModal}>
                Create Layer
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    placeholder="Enter Layer Name"
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setNameValid);
                      setLayerName(val.target.value);
                    }}
                    className={`${NameValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!NameValid ? "Name is Required" : ""}
                  </p>
                  <Input
                    type="number"
                    className="mb-3"
                    placeholder="Enter Order"
                    onChange={(val) => {
                      setOrder(val.target.value);
                      isInputValid(val.target.value, setOrderValid);
                      if (val.target.value > 100 || val.target.value < 1) {
                        setOrderValid(false);
                      }
                    }}
                    className={`${OrderValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!OrderValid
                      ? "Order is Required and must be between 1 and 100"
                      : ""}
                  </p>
                </div>
                <div>
                  <h6>Form NFT when detached:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="true"
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      True
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="false"
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      False
                    </label>
                  </div>
                  <p className="ErrMsg">
                    {!DetachedValid ? "Detached value is Required" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeCreateLayerModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={CreateClicked}
                  onClick={() => createLayer()}
                >
                  Create
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={deleteLayerStatus}
              toggle={closeDeleteLayer}
              centered
              size="m"
            >
              <ModalHeader toggle={closeDeleteLayer}>Layer</ModalHeader>
              <ModalBody>
                <p>Are you sure you want to Delete this layer?</p>
              </ModalBody>
              <ModalFooter>
                <Button onClick={closeDeleteLayer}>Cancel</Button>
                <Button color="danger" onClick={deleteLayer}>
                  Delete
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={updateLayerStatus}
              toggle={closeUpdateLayerModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUpdateLayerModal}>
                Update Layer
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    value={layerName}
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setUpdateNameValid);
                      setLayerName(val.target.value);
                    }}
                    className={`${UpdateNameValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!UpdateNameValid ? "Name is Required" : ""}
                  </p>
                  <Input
                    type="number"
                    className="mb-3"
                    value={order}
                    onChange={(val) => {
                      setOrder(val.target.value);
                      isInputValid(val.target.value, setUpdateOrderValid);
                      if (val.target.value > 100 || val.target.value < 1) {
                        setUpdateOrderValid(false);
                      }
                    }}
                    className={`${UpdateOrderValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!UpdateOrderValid
                      ? "Order is Required and must be between 1 and 100"
                      : ""}
                  </p>
                </div>
                <div>
                  <h6>Form NFT when detached:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="true"
                      // checked={detachedResult? true: false}
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      True
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="false"
                      // checked={!detachedResult? true: false}
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      False
                    </label>
                  </div>
                  <p className="ErrMsg">
                    {!UpdateDetachedValid ? "Detached value is Required" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUpdateLayerModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={UpdateClicked}
                  onClick={() => updateLayer()}
                >
                  Update
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={uploadImageStatus}
              toggle={closeUploadImageModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUploadImageModal}>
                Upload Image
              </ModalHeader>
              <ModalBody>
                <div>
                  <input
                    type="file"
                    name="file"
                    placeholder="Upload image"
                    className="mb-3"
                    onChange={changeHandler}
                  />
                  {isFilePicked ? (
                    <div>
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        className="preview_img"
                      />
                    </div>
                  ) : (
                    <p>Select a file.</p>
                  )}
                  <p id="NameErrMsg" className="ErrMsg">
                    {!ImageValid ? "Image is Required" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUploadImageModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={UploadClicked}
                  onClick={() => uploadImages()}
                >
                  Upload
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <Row>
                    {layers && layers.length > 0 ? (
                      layers.map((item) => {
                        return (
                          <>
                            <div className="collection-card card">
                              <img
                                className="card-img-top card-img"
                                src={item.image_url ? item.image_url : NoImage}
                                onClick={() => handleRoute(item)}
                                alt=""
                              />
                              <div className="card-body">
                                <h4 className="card-title">{item.name}</h4>
                                <h6>
                                  ( Order: {item.order ? item.order : 0} )
                                </h6>
                                <p>
                                  <b>Form NFT When Detached: </b>
                                  {item.form_nft_when_detached
                                    ? "True"
                                    : item.form_nft_when_detached === false
                                    ? "False"
                                    : "Not selected"}
                                </p>
                              </div>
                              <div className="collection-btn">
                                <Button
                                  color="secondary"
                                  className="variation-upload-img"
                                  onClick={() => handleUploadImage(item._id)}
                                >
                                  Upload Image
                                </Button>
                                <Button
                                  color="primary"
                                  className="variation-update-btn"
                                  onClick={() => handleUpdateLayer(item)}
                                >
                                  Update
                                </Button>
                                <Button
                                  color="danger"
                                  onClick={() => handleDeleteLayer(item._id)}
                                >
                                  Delete
                                </Button>
                              </div>
                            </div>
                          </>
                        );
                      })
                    ) : (
                      <Row>
                        <NoContent />
                      </Row>
                    )}
                  </Row>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Layers;
