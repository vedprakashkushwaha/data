import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Input,
  Button,
} from "reactstrap";
import { useLocation } from "react-router-dom";
import {
  _getBatchImages,
  _updateBatchDetails,
  _getBatchData,
} from "src/api/batch";
import { notifyError, notifySuccess } from "../../utils/notification";
import NoContent from "src/views/extras/NoContent";
import { Progress } from "reactstrap";
import PaginatedItems from "./PaginatedItems";
import ClipLoader from "react-spinners/ClipLoader";
import { io } from "socket.io-client";

const BatchImages = () => {
  const [updateBatchStatus, setUpdateBatchStatus] = useState(false);
  const [number, setNumber] = useState("");
  const [namePrefix, setNamePrefix] = useState("");
  const [offset, setOffset] = useState("");
  const [batchData, setBatchData] = useState("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [batches, setBatches] = useState([]);
  let location = useLocation();
  const batchId = location ? location.state.batchId : "";
  const color = "black";

  useEffect(() => {
    getBatchData();
    getBatchImages();
    getImageGenerationProgress();
  }, []);

  const getImageGenerationProgress = () => {
    const socket = io("http://localhost:8001");

    socket.on("asking_for_batch_id", () => {
      socket.emit("batch_id", batchId);
    });

    socket.on("progress", (progress) => {
      console.log("progress: ", progress);
      setProgress(progress);
      if (progress === 100) {
        getBatchImages();
      }
    });
  };

  const getBatchData = async () => {
    try {
      _getBatchData(batchId).then(async (res) => {
        console.log("check result for get batch data", res);
        if (res && res.status === 200) {
          setBatchData(res.data.data);
        } else {
          setBatchData("");
          console.log(res ? res.data.message : "Error!!");
        }
      });
      setBatches([]);
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const getBatchImages = async () => {
    setLoading(true);
    let requestData = {
      image_batch_id: batchId,
      max_entries: 20,
      offset: 0,
    };
    try {
      _getBatchImages(requestData).then(async (res) => {
        console.log("check result for get images", res);
        if (res && res.status === 200) {
          setBatches(res.data.data.images);
          setLoading(false);
        } else {
          setBatches([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
      setBatches([]);
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const updateBatchDetails = async () => {
    try {
      if (number === "" || namePrefix === "" || offset === "") {
        notifyError("Enter Batch Details");
      } else {
        let requestData = {
          number: number,
          name_prefix: namePrefix,
          numbering_offset: offset,
        };
        _updateBatchDetails(batchId, requestData).then(async (res) => {
          console.log("response of update batch details:", res);
          if (res.status === 201) {
            notifySuccess(res.data.message);
            setProgress(0);
            // getBatchImages();
            setUpdateBatchStatus(false);
            getBatchData();
            setNumber("");
            setNamePrefix("");
            setOffset("");
          } else {
            console.log(res ? res.data.message : "Error!!");
          }
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const closeUpdateBatchModal = () => {
    setUpdateBatchStatus(false);
    setNumber("");
    setNamePrefix("");
    setOffset("");
  };

  const handleUpdateBatchModal = () => {
    setUpdateBatchStatus(true);
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Generated Images</b>
              </CCol>
              {batchData.status === "pending" ? (
                <CCol>
                  <Button
                    color="success"
                    className="float-right"
                    onClick={() => handleUpdateBatchModal()}
                  >
                    Generate Images
                  </Button>
                </CCol>
              ) : (
                ""
              )}
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={updateBatchStatus}
              toggle={closeUpdateBatchModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUpdateBatchModal}>
                Generate Images
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    type="number"
                    placeholder="Enter Number"
                    onChange={(val) => setNumber(val.target.value)}
                  />
                  <br />
                  <Input
                    placeholder="Enter Name Prefix"
                    onChange={(val) => setNamePrefix(val.target.value)}
                  />
                  <br />
                  <Input
                    type="number"
                    placeholder="Enter Numbering Offset"
                    onChange={(val) => setOffset(val.target.value)}
                  />
                </div>
                <br />
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUpdateBatchModal}>
                  Cancel
                </Button>
                <Button color="primary" onClick={() => updateBatchDetails()}>
                  Update
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              {batchData.number &&
              batchData.name_prefix &&
              batchData.numbering_offset ? (
                batches.length > 0 ? (
                  <PaginatedItems itemsPerPage={8} batchData={batches} />
                ) : (
                  <Row>
                    <div className="test-progress mb-3">
                      <Progress value={progress} />
                    </div>
                    <ClipLoader color={color} loading={loading} size={150} />
                  </Row>
                )
              ) : (
                <NoContent />
              )}
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default BatchImages;
