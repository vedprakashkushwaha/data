import React from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import collaboratorsImg from "src/assets/icons/images/people.png";
import layersImg from "src/assets/icons/images/layers.png";
import configurationImg from "src/assets/icons/images/Configuration.png";
import { useHistory, useLocation } from "react-router-dom";
import { updateBreadCrumb } from "src/utils/utilities";

const CollectionItem = () => {
  const history = useHistory();
  let location = useLocation();
  const collectionId = location ? location.state.collectionId.id : "";

  const handleLayers = () => {
    updateBreadCrumb({ pathname: "/layers", name: "Layers" });

    history.push({
      pathname: "/layers",
      state: {
        collectionId: { collectionId },
      },
    });
  };

  const handleManageCollaboratorsRoute = () => {
    updateBreadCrumb({ pathname: "/collaborators", name: "Collaborators" });

    history.push({
      pathname: "/collaborators",
      state: {
        collectionId: { collectionId },
      },
    });
  };

  const handleConfigurationRoute = () => {
    updateBreadCrumb({ pathname: "/configurations", name: "Configurations" });

    history.push({
      pathname: "/configurations",
      state: {
        collectionId: { collectionId },
      },
    });
  };

  const handleGenerateImage = () => {
    updateBreadCrumb({ pathname: "/generateImage", name: "Generate Image" });

    history.push({
      pathname: "/generateImage",
      state: {
        collectionId: { collectionId },
      },
    });
  };

  return (
    <>
      <CRow>
        <CCol xs="3">
          <CCard>
            <CCardHeader>
              <div className="text-center">
                <b>Layers</b>
              </div>
            </CCardHeader>
            <CCardBody>
              <div className="text-center" onClick={handleLayers}>
                <img
                  alt="collection_img"
                  src={layersImg}
                  className="collaborator-icon"
                ></img>
              </div>
            </CCardBody>
          </CCard>
        </CCol>

        <CCol xs="3">
          <CCard>
            <CCardHeader>
              <div className="text-center">
                <b>Collaborators</b>
              </div>
            </CCardHeader>
            <CCardBody>
              <div
                className="text-center"
                onClick={handleManageCollaboratorsRoute}
              >
                <img
                  alt="collection_img"
                  src={collaboratorsImg}
                  className="collaborator-icon"
                ></img>
              </div>
            </CCardBody>
          </CCard>
        </CCol>

        <CCol xs="3">
          <CCard>
            <CCardHeader>
              <div className="text-center">
                <b>Configurations</b>
              </div>
            </CCardHeader>
            <CCardBody>
              <div className="text-center" onClick={handleConfigurationRoute}>
                <img
                  alt="collection_img"
                  src={configurationImg}
                  className="collaborator-icon"
                ></img>
              </div>
            </CCardBody>
          </CCard>
        </CCol>

        <CCol xs="3">
          <CCard>
            <CCardHeader>
              <div className="text-center">
                <b>Generate Image</b>
              </div>
            </CCardHeader>
            <CCardBody>
              <div className="text-center" onClick={handleGenerateImage}>
                <img
                  alt="collection_img"
                  src={layersImg}
                  className="collaborator-icon"
                ></img>
              </div>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

export default CollectionItem;
