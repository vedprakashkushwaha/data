import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Input,
  ModalFooter,
} from "reactstrap";
import { useLocation } from "react-router-dom";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import { notifyError, notifySuccess } from "../../utils/notification";
import {
  _createVariations,
  _getVariations,
  _deleteVariation,
  _updateVariation,
  _uploadVariationImage,
} from "src/api/variations";
import isInputValid from "src/validation/validate";
import NoContent from "src/views/extras/NoContent";
import { updateBreadCrumb } from "src/utils/utilities";
import { useHistory } from "react-router-dom";

const Variations = () => {
  const [createVariationStatus, setCreateVariationStatus] = useState(false);
  const [variationName, setVariationName] = useState("");
  const [rarity, setRarity] = useState("");
  let location = useLocation();
  const layerId = location ? location.state.layerId.id : "";
  const [variations, setVariations] = useState([]);
  const [deleteVariationStatus, setDeleteVariationStatus] = useState(false);
  const [selectedVariationId, setSelectedVariationId] = useState("");
  const [updateVariationStatus, setUpdateVariationStatus] = useState(false);
  const [uploadImageStatus, setUploadImageStatus] = useState(false);
  const [selectedFile, setSelectedFile] = useState();
  const [isFilePicked, setIsFilePicked] = useState(false);
  const [imageType, setImageType] = useState("");
  const [detachedResult, setDetachedResult] = useState("");
  const [CreateClicked, setCreateClicked] = useState(false);
  const [UpdateClicked, setUpdateClicked] = useState(false);
  const [UploadClicked, setUploadClicked] = useState(false);
  const [NameValid, setNameValid] = useState(true);
  const [CreateName, setCreateName] = useState("");
  const [RarityValid, setRarityValid] = useState(true);
  const [UpdateNameValid, setUpdateNameValid] = useState(true);
  const [UploadTypeValid, setUploadTypeValid] = useState(true);
  const [ImageValid, setImageValid] = useState(true);
  const [DetachedValid, setDetachedValid] = useState(true);

  const history = useHistory();

  const handleCreateVariationModal = () => {
    setCreateVariationStatus(true);
  };

  const closeCreateVariationModal = () => {
    setCreateVariationStatus(false);
    setVariationName("");
    setRarity("");
    setNameValid(true);
    setRarityValid(true);
    setDetachedResult("");
    setDetachedValid(true);
  };

  const createVariation = async () => {
    try {
      if (
        variationName === "" ||
        rarity === "" ||
        rarity > 100 ||
        rarity < 1 ||
        detachedResult === ""
      ) {
        isInputValid(variationName, setNameValid);
        isInputValid(rarity, setRarityValid);
        isInputValid(detachedResult, setDetachedValid);
        if (rarity > 100 || rarity < 1) {
          setRarityValid(false);
        }
        notifyError(
          "Enter Variation Name, Detached Status and Rarity Level must be between 1 and 100"
        );
      } else {
        setCreateClicked(true);
        let requestData = {
          name: variationName,
          layer_id: layerId,
          rarity: rarity,
          form_nft_when_detached: detachedResult,
        };
        _createVariations(requestData).then(async (res) => {
          console.log("response of create Variations:", res);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            closeCreateVariationModal();
            setCreateVariationStatus(false);
            getVariations();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          setCreateClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  useEffect(() => {
    getVariations();
  }, []);

  const getVariations = async () => {
    try {
      let requestData = {
        layer_id: layerId,
      };
      _getVariations(requestData).then(async (res) => {
        if (res && res.status === 200) {
          setVariations(res.data.data.variations);
        } else {
          setVariations([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleDeleteVariation = (variationId) => {
    setSelectedVariationId(variationId);
    setDeleteVariationStatus(true);
  };

  const closeDeleteVariation = () => {
    setDeleteVariationStatus(false);
  };

  const deleteVariation = async () => {
    try {
      let requestData = {
        variationId: selectedVariationId,
      };
      _deleteVariation(requestData).then(async (res) => {
        console.log("response to delete variation:", res);
        if (res.status === 200) {
          notifySuccess(res.data.message);
          setDeleteVariationStatus(false);
          setSelectedVariationId("");
          getVariations();
        } else {
          console.log(res ? res.data.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleUpdateVariation = (variationId, name, rarity) => {
    setSelectedVariationId(variationId);
    setUpdateVariationStatus(true);
    setVariationName(name);
    setRarity(rarity);
    isInputValid(name, setUpdateNameValid);
  };

  const closeUpdateVariationModal = () => {
    setUpdateVariationStatus(false);
    setVariationName("");
    setRarity("");
    setNameValid(true);
    setRarityValid(true);
  };

  const updateVariation = async () => {
    try {
      if (variationName === "" || rarity === "" || rarity > 100 || rarity < 1) {
        isInputValid(variationName, setNameValid);
        isInputValid(rarity, setRarityValid);
        if (rarity > 100 || rarity < 1) {
          setRarityValid(false);
        }
        notifyError(
          "Enter Variation Name and Rarity Level must be between 1 and 100"
        );
      } else {
        setUpdateClicked(true);
        let data = {
          name: variationName,
          nftLayerId: layerId,
          rarity: rarity,
        };
        let requestData = {
          variationId: selectedVariationId,
        };
        _updateVariation(requestData, data).then(async (res) => {
          console.log("response to update variation:", res);
          if (res && res.status === 200) {
            notifySuccess(res.data.message);
            setUpdateVariationStatus(false);
            setSelectedVariationId("");
            setImageType("");
            getVariations();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          setUpdateClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleUploadImage = (variationId) => {
    setSelectedVariationId(variationId);
    setUploadImageStatus(true);
  };

  const closeUploadImageModal = () => {
    setUploadImageStatus(false);
    setIsFilePicked(false);
    setSelectedFile("");
    setImageType(""); //I added from this line.
    setUploadTypeValid(true);
    setImageValid(true);
  };

  const uploadImage = async () => {
    try {
      isInputValid(imageType, setUploadTypeValid);
      if (!selectedFile) {
        notifyError("No file uploaded");
        setImageValid(false);
      } else if (imageType === "") {
        notifyError("Select the Image type");
      } else {
        setImageValid(true);
        setUploadClicked(true);
        let data = {
          variationId: selectedVariationId,
          imageType: imageType,
        };
        let requestData = new FormData();
        requestData.append("image", selectedFile);
        _uploadVariationImage(data, requestData).then(async (res) => {
          console.log("response of upload image:", res, res.status);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            setUploadImageStatus(false);
            setIsFilePicked(false);
            setSelectedFile("");
            getVariations();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          setUploadClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const changeHandler = (event) => {
    setSelectedFile(event.target.files[0]);
    setIsFilePicked(true);
    setImageValid(true);
  };

  const handleRadioChange = (e) => {
    isInputValid(e.target.value, setUploadTypeValid);
    setImageType(e.target.value);
  };

  const handleDetachRadioChange = (e) => {
    isInputValid(e.target.value, setDetachedValid);
    setDetachedResult(e.target.value);
  };

  const handleRoute = (item) => {
    let name = item.name;
    let id = item._id;
    updateBreadCrumb({ pathname: "/variationDetails", name: name }, "update");

    history.push({
      pathname: "/variationDetails",
      state: {
        variationName: { name },
        variationId: { id },
      },
    });
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Variations</b>
              </CCol>
              <CCol>
                <Button
                  color="success"
                  className="float-right"
                  onClick={() => handleCreateVariationModal()}
                >
                  Add Variation
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={createVariationStatus}
              toggle={closeCreateVariationModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeCreateVariationModal}>
                Create Variation
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    placeholder="Enter Variation Name"
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setNameValid);
                      setVariationName(val.target.value);
                      setCreateName(val.target.value);
                    }}
                    className={` ${NameValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!NameValid ? "Name is Required" : ""}
                  </p>

                  <br />
                  <Input
                    type="number"
                    placeholder="Enter Rarity (in percentage)"
                    className="mb-3"
                    min="0"
                    max="100"
                    step="1"
                    required
                    onChange={(val) => {
                      isInputValid(val.target.value, setRarityValid);
                      if (val.target.value > 100 || val.target.value < 1) {
                        setRarityValid(false);
                      }
                      setRarity(val.target.value);
                    }}
                    className={`${RarityValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!RarityValid
                      ? "Rarity is Required and must be between 1 and 100"
                      : ""}
                  </p>
                </div>
                <div>
                  <h6>Form NFT when detached:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="true"
                      // checked
                      onClick={handleDetachRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      True
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="false"
                      onClick={handleDetachRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      False
                    </label>
                  </div>
                  <p className="ErrMsg">
                    {!DetachedValid ? "Detached value is Required" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeCreateVariationModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={CreateClicked}
                  onClick={() => createVariation()}
                >
                  Create
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={deleteVariationStatus}
              toggle={closeDeleteVariation}
              centered
              size="m"
            >
              <ModalHeader toggle={closeDeleteVariation}>Variation</ModalHeader>
              <ModalBody>
                <p>Are you sure you want to Delete this variation?</p>
              </ModalBody>
              <ModalFooter>
                <Button onClick={closeDeleteVariation}>Cancel</Button>
                <Button color="danger" onClick={deleteVariation}>
                  Delete
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={updateVariationStatus}
              toggle={closeUpdateVariationModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUpdateVariationModal}>
                Update Variation
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    value={variationName}
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setUpdateNameValid);
                      setVariationName(val.target.value);
                    }}
                    className={` ${UpdateNameValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!UpdateNameValid ? "Name is Required" : ""}
                  </p>
                  <br />
                  <Input
                    type="number"
                    value={rarity}
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setRarityValid);
                      if (val.target.value > 100 || val.target.value < 1) {
                        setRarityValid(false);
                      }
                      setRarity(val.target.value);
                    }}
                    className={`${RarityValid ? "" : "InputError"}`}
                  />
                  <p>
                    {!RarityValid
                      ? "Rarity is Required and must be between 1 and 100"
                      : ""}
                  </p>
                </div>
                <div>
                  <h6>Form NFT when detached:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="true"
                      onClick={handleDetachRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      True
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="false"
                      onClick={handleDetachRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      False
                    </label>
                  </div>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUpdateVariationModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={UpdateClicked}
                  onClick={() => updateVariation()}
                >
                  Update
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={uploadImageStatus}
              toggle={closeUploadImageModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUploadImageModal}>
                Upload Image
              </ModalHeader>
              <ModalBody>
                <div className="mb-3">
                  <input
                    type="file"
                    name="file"
                    placeholder="Upload image"
                    className="mb-3"
                    onChange={changeHandler}
                  />
                  {isFilePicked ? (
                    <div>
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        className="preview_img"
                      />
                    </div>
                  ) : (
                    <p>Select a file.</p>
                  )}
                  <p id="NameErrMsg" className="ErrMsg">
                    {!ImageValid ? "Image is Required" : ""}
                  </p>
                </div>
                <br />
                <div class="form-check">
                  <h6>Type:</h6>
                  <Input
                    className="form-check-input"
                    id="flexRadioDefault1"
                    type="radio"
                    name="flexRadioDefault"
                    value="Standalone"
                    // checked
                    onClick={handleRadioChange}
                  />
                  <label className="form-check-label" for="flexRadioDefault1">
                    Standalone
                  </label>
                </div>
                <div className="form-check">
                  <Input
                    className="form-check-input"
                    id="flexRadioDefault2"
                    type="radio"
                    name="flexRadioDefault"
                    value="Combined"
                    onClick={handleRadioChange}
                  />
                  <label className="form-check-label" for="flexRadioDefault2">
                    Combined
                  </label>
                  <p className="ErrMsg">
                    {!UploadTypeValid ? "Type is Required" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUploadImageModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={UploadClicked}
                  onClick={() => uploadImage()}
                >
                  Upload
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <Row>
                    {variations && variations.length > 0 ? (
                      variations.map((item) => {
                        return (
                          <>
                            <div className="card collection-card">
                              <img
                                className="card-img card-img-top"
                                src={
                                  item.images[0].image_url
                                    ? item.images[0].image_url
                                    : item.images[1].image_url
                                    ? item.images[1].image_url
                                    : NoImage
                                }
                                alt=""
                                onClick={() => handleRoute(item)}
                              />
                              <div className="card-body">
                                <h4 className="card-title">{item.name}</h4>
                                <h6>( Rarity: {item.rarity}% )</h6>
                                <p>
                                  <b>Form NFT When Detached: </b>
                                  {item.form_nft_when_detached
                                    ? "True"
                                    : item.form_nft_when_detached === false
                                    ? "False"
                                    : "Not selected"}
                                </p>
                              </div>
                              <div className="collection-btn">
                                <Button
                                  color="secondary"
                                  className="variation-upload-img"
                                  onClick={() => handleUploadImage(item._id)}
                                >
                                  Upload Image
                                </Button>
                                <Button
                                  color="primary"
                                  className="variation-update-btn"
                                  onClick={() =>
                                    handleUpdateVariation(
                                      item._id,
                                      item.name,
                                      item.rarity
                                    )
                                  }
                                >
                                  Update
                                </Button>
                                <Button
                                  color="danger"
                                  onClick={() =>
                                    handleDeleteVariation(item._id)
                                  }
                                >
                                  Delete
                                </Button>
                              </div>
                            </div>
                          </>
                        );
                      })
                    ) : (
                      <Row>
                        <NoContent />
                      </Row>
                    )}
                  </Row>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Variations;
