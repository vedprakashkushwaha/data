import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Col,
  Input,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import { useLocation } from "react-router-dom";
import {
  _getCollaborators,
  _addCollaborator,
  _removeCollaborator,
} from "src/api/collaborators";
import { notifyError, notifySuccess } from "./../../utils/notification";
import NoContent from "src/views/extras/NoContent";

const Collaborators = () => {
  let location = useLocation();
  const [collaborators, setCollaborators] = useState([]);
  const collection = location ? location.state.collectionId.collectionId : "";
  const [addCollaboratorStatus, setAddCollaboratorStatus] = useState(false);
  const [collaboratorEmail, setCollaboratorEmail] = useState("");
  const [ColbtrEmlValid, setColbtrEmlValid] = useState(true);

  useEffect(() => {
    getCollaborators();
  }, []);

  const getCollaborators = async () => {
    try {
      let requestData = {
        collectionId: location ? location.state.collectionId.collectionId : "",
      };
      _getCollaborators(requestData).then(async (res) => {
        if (res && res.status === 200) {
          setCollaborators(res.data.data[0].collaborators);
        } else {
          setCollaborators([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const validateEmail = (eml) => {
    return eml.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  };

  const addCollaborator = async () => {
    try {
      if (!validateEmail(collaboratorEmail)) {
        setColbtrEmlValid(false);
        notifyError("Enter a Valid Email");
      } else {
        let requestData = {
          collection_id: collection,
          email: collaboratorEmail,
        };
        _addCollaborator(requestData).then(async (res) => {
          console.log("response of add collaborator:", res);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            getCollaborators();
            closeAddCollaboratorModal();
          } else if (res.status === 500) {
            notifyError(res.data.message);
          } else {
            console.log(res ? res.data.message : "Error!!");
          }
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const removeCollaborator = async (userId) => {
    try {
      let requestData = {
        creator_id: userId,
      };
      _removeCollaborator(collection, requestData).then(async (res) => {
        console.log("response of remove collaborator:", res);
        if (res.status === 200) {
          notifySuccess(res.data.message);
          getCollaborators();
        } else {
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleAddCollaboratorModal = () => {
    setAddCollaboratorStatus(true);
  };

  const closeAddCollaboratorModal = () => {
    setAddCollaboratorStatus(false);
    setCollaboratorEmail("");
    setColbtrEmlValid(true);
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Collaborators</b>
              </CCol>
              <CCol>
                <Button
                  color="success"
                  className="float-right"
                  onClick={() => handleAddCollaboratorModal()}
                >
                  Add Collaborator
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={addCollaboratorStatus}
              toggle={closeAddCollaboratorModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeAddCollaboratorModal}>
                Add Collaborator
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    placeholder="Enter Collaborator Email Address"
                    type="email"
                    onChange={(val) => {
                      if (validateEmail(val.target.value)) {
                        setCollaboratorEmail(val.target.value);
                        setColbtrEmlValid(true);
                      } else {
                        setColbtrEmlValid(false);
                      }
                    }}
                    className={`${ColbtrEmlValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!ColbtrEmlValid ? "Not a valid Email" : ""}
                  </p>
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeAddCollaboratorModal}>
                  Cancel
                </Button>
                <Button color="primary" onClick={() => addCollaborator()}>
                  Add
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              <Row>
                <Col>
                  {collaborators && collaborators.length > 0 ? (
                    <Row>
                      <table class="table table-striped collaborator-tbl">
                        <thead>
                          <tr>
                            <th scope="col">Collaborator</th>
                            <th scope="col">Options</th>
                          </tr>
                        </thead>
                        <tbody>
                          {collaborators
                            ? collaborators.map((item) => {
                                return (
                                  <tr>
                                    <td>{item.email ? item.email : ""}</td>
                                    <td>
                                      <Button
                                        color="danger"
                                        onClick={() =>
                                          removeCollaborator(item._id)
                                        }
                                      >
                                        Remove
                                      </Button>
                                    </td>
                                  </tr>
                                );
                              })
                            : ""}
                        </tbody>
                      </table>
                    </Row>
                  ) : (
                    <Row>
                      <Col>
                        {collaborators && collaborators.length > 0 ? (
                          <Row>
                            <table className="table table-striped collaborator-tbl">
                              <thead>
                                <tr>
                                  <th scope="col">Collaborator</th>
                                  <th scope="col">Options</th>
                                </tr>
                              </thead>
                              <tbody>
                                {collaborators
                                  ? collaborators.map((item) => {
                                      return (
                                        <tr>
                                          <td>{item.email}</td>
                                          <td>
                                            <Button
                                              color="danger"
                                              onClick={() =>
                                                removeCollaborator(item._id)
                                              }
                                            >
                                              Remove
                                            </Button>
                                          </td>
                                        </tr>
                                      );
                                    })
                                  : ""}
                              </tbody>
                            </table>
                          </Row>
                        ) : (
                          <Row>
                            <NoContent />
                          </Row>
                        )}
                      </Col>
                    </Row>
                  )}
                  ;
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Collaborators;
