import React, { useState } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import { Row, Col, Input, Button } from "reactstrap";
import { useLocation } from "react-router-dom";
import Dropdown from "react-dropdown";
import "react-dropdown/style.css";
import { _submitConfiguration } from "src/api/configutaion";
import { notifySuccess } from "../../utils/notification";

const Configurations = () => {
  let location = useLocation();
  const collectionId = location ? location.state.collectionId.collectionId : "";
  const [name, setName] = useState("");
  const [blockchain, setBlockchain] = useState("");
  const [testnet, setTestnet] = useState("");
  const [price, setPrice] = useState("");
  const [currency, setCurrency] = useState("");
  const [payeeAddress, setPayeeAddress] = useState("");
  const [reservedNumber, setReservedNumber] = useState(0);
  const [whitelistAddresses, setWhitelistAddresses] = useState("");
  const [earlyAccessTime, setEarlyAccessTime] = useState("");
  const [launchDatetime, setLaunchDatetime] = useState("");
  const [metadataReveal, setMetadataReveal] = useState("");
  const [mintLimit, setMintLimit] = useState("");
  const [metadataRevealTime, setMetadataRevealTime] = useState("");
  const [imageBatches, setImageBatches] = useState("");
  const booleanOptions = ["true", "false"];
  const currencyOptions = ["USD", "MATIC"];

  const onTestnetSelect = (e) => {
    setTestnet(e.value);
  };

  const onCurrencySelect = (e) => {
    setCurrency(e.value);
  };

  const launchDatetimeChange = (ev) => {
    if (!ev.target["validity"].valid) return;
    const dt = ev.target["value"] + ":00Z";
    setLaunchDatetime(dt);
  };

  const earlyAccessTimeChange = (ev) => {
    if (!ev.target["validity"].valid) return;
    const dt = ev.target["value"] + ":00Z";
    setEarlyAccessTime(dt);
  };

  const onMetadatRevealSelect = (e) => {
    setMetadataReveal(e.value);
  };

  const metadataRevealTimeChange = (ev) => {
    if (!ev.target["validity"].valid) return;
    const dt = ev.target["value"] + ":00Z";
    setMetadataRevealTime(dt);
  };

  const submitConfigurations = async () => {
    try {
      let requestData = {
        collection_id: collectionId,
        name: name,
        blockchain: blockchain,
        use_testnet: testnet,
        price: price,
        currency: currency,
        payee_address: payeeAddress,
        num_reserved_for_promotion: reservedNumber,
        whitelist_addresses: whitelistAddresses,
        early_access_time: earlyAccessTime,
        launch_time: launchDatetime,
        use_metadata_reveal: metadataReveal,
        mint_limit: mintLimit,
        metadata_reveal_time: metadataRevealTime,
        image_batches: imageBatches,
      };
      _submitConfiguration(requestData).then(async (res) => {
        console.log("response of submit configuration:", res);
        if (res && res.status === 201) {
          notifySuccess(res.data.message);
        } else {
          console.log(res ? res.data.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="10">
                <b>Configurations</b>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <CRow className="configuration-padding">
                    <CCol xs="3">Name</CCol>
                    <CCol>
                      <Input onChange={(val) => setName(val.target.value)} />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Blockchain</CCol>
                    <CCol>
                      <Input
                        onChange={(val) => setBlockchain(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Use Testnet</CCol>
                    <CCol>
                      <Dropdown
                        options={booleanOptions}
                        onChange={onTestnetSelect}
                        placeholder="Select an option"
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Price</CCol>
                    <CCol>
                      <Input
                        type="number"
                        value={price}
                        onChange={(val) => setPrice(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Currency</CCol>
                    <CCol>
                      <Dropdown
                        options={currencyOptions}
                        onChange={onCurrencySelect}
                        placeholder="Select an option"
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Payee Address</CCol>
                    <CCol>
                      <Input
                        onChange={(val) => setPayeeAddress(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Number Reserved for Promotion</CCol>
                    <CCol>
                      <Input
                        type="number"
                        value={reservedNumber}
                        onChange={(val) => setReservedNumber(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Whitelist Addresses</CCol>
                    <CCol>
                      <Input
                        onChange={(val) =>
                          setWhitelistAddresses(val.target.value)
                        }
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Early Access Time</CCol>
                    <CCol>
                      <input
                        type="datetime-local"
                        value={(earlyAccessTime || "")
                          .toString()
                          .substring(0, 16)}
                        onChange={earlyAccessTimeChange}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Launch Time</CCol>
                    <CCol>
                      <input
                        type="datetime-local"
                        value={(launchDatetime || "")
                          .toString()
                          .substring(0, 16)}
                        onChange={launchDatetimeChange}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Use Metadata Reveal</CCol>
                    <CCol>
                      <Dropdown
                        options={booleanOptions}
                        onChange={onMetadatRevealSelect}
                        placeholder="Select an option"
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Mint Limit</CCol>
                    <CCol>
                      <Input
                        type="number"
                        value={mintLimit}
                        onChange={(val) => setMintLimit(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Metadata Reveal Time</CCol>
                    <CCol>
                      <input
                        type="datetime-local"
                        disabled={
                          metadataReveal === "" || metadataReveal === "false"
                            ? true
                            : false
                        }
                        value={(metadataRevealTime || "")
                          .toString()
                          .substring(0, 16)}
                        onChange={metadataRevealTimeChange}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol xs="3">Image Batches</CCol>
                    <CCol>
                      <Input
                        onChange={(val) => setImageBatches(val.target.value)}
                      />
                    </CCol>
                  </CRow>
                  <CRow className="configuration-padding">
                    <CCol className="submit-btn">
                      <Button
                        color="success"
                        onClick={() => submitConfigurations()}
                      >
                        Submit
                      </Button>
                    </CCol>
                  </CRow>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Configurations;
