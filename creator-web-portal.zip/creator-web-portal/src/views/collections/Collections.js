import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Input,
  Button,
} from "reactstrap";
import { useHistory } from "react-router-dom";
import {
  _createCollection,
  _getCollections,
  _updateCollection,
  _deleteCollection,
} from "src/api/collection";
import { notifyError, notifySuccess } from "../../utils/notification";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import { updateBreadCrumb } from "src/utils/utilities";
import isInputValid from "src/validation/validate";
import NoContent from "src/views/extras/NoContent";

const Collections = () => {
  const history = useHistory();
  const [createCollectionStatus, setCreateCollectionStatus] = useState(false);
  const [collectionName, setCollectionName] = useState("");
  const [collections, setCollections] = useState([]);
  const [selectedFile, setSelectedFile] = useState();
  const [isFilePicked, setIsFilePicked] = useState(false);
  const [updateCollectionStatus, setUpdateCollectionStatus] = useState(false);
  const [selectedCollectionId, setSelectedCollectionId] = useState("");
  const [deleteCollectionStatus, setDeleteCollectionStatus] = useState(false);
  const [buttonClicked, setButtonClicked] = useState(false);
  const [updateBtnClicked, setUpdateBtnClicked] = useState(false);
  const [collectionDesc, setCollectionDesc] = useState("");
  const [typeResult, setTypeResult] = useState("");
  const [NameValid, setNameValid] = useState(true);
  const [DescValid, setDescValid] = useState(true);
  const [UpdateNameValid, setUpdateNameValid] = useState(true);
  const [UpdateDescValid, setUpdateDescValid] = useState(true);
  const [TypeValid, setTypeValid] = useState(true);
  const [UpdateName, setUpdateName] = useState(collectionName);
  const [UpdateDesc, setUpdateDesc] = useState(collectionDesc);

  useEffect(() => {
    getCollections();
  }, []);

  const getCollections = async () => {
    try {
      _getCollections().then(async (res) => {
        if (res && res.status === 200) {
          setCollections(res.data.data);
        } else {
          setCollections([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleRoute = (item) => {
    let name = item.name;
    let id = item._id;

    updateBreadCrumb({ pathname: "/collectionItem", name: name }, "update");

    history.push({
      pathname: "/collectionItem",
      state: {
        collectionName: { name },
        collectionId: { id },
      },
    });
  };

  const closeCreateCollectionModal = () => {
    setCreateCollectionStatus(false);
    setSelectedFile("");
    setIsFilePicked(false);
    setCollectionName("");
    setCollectionDesc("");
    setTypeResult("");
    setNameValid(true);
    setDescValid(true);
    setTypeValid(true);
  };

  const createCollection = async () => {
    try {
      if (collectionName === "" || collectionDesc === "" || typeResult === "") {
        isInputValid(collectionName, setNameValid);
        isInputValid(collectionDesc, setDescValid);
        isInputValid(typeResult, setTypeValid);
        notifyError("Enter the Collection Name, Description and Type");
      } else {
        setButtonClicked(true);
        let requestData = new FormData();
        requestData.append("name", collectionName);
        requestData.append("description", collectionDesc);
        requestData.append("image", selectedFile);
        requestData.append("type", typeResult);
        _createCollection(requestData).then(async (res) => {
          console.log("response of create collection:", res);
          if (res.status === 201) {
            notifySuccess(res.data.message);
            closeCreateCollectionModal();
            setCreateCollectionStatus(false);
            setCollectionDesc("");
            setCollectionName("");
            setIsFilePicked("");
            setSelectedFile("");
            setTypeResult("");
            getCollections();
          } else {
            console.log(res ? res.data.message : "Error!!");
          }
          setButtonClicked(false);
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleCreateCollectionModal = () => {
    setCreateCollectionStatus(true);
    setSelectedFile("");
    setIsFilePicked(false);
  };

  const changeHandler = (event) => {
    setSelectedFile(event.target.files[0]);
    setIsFilePicked(true);
  };

  const handleUpdateCollection = (item) => {
    setUpdateName(item.name);
    setUpdateDesc(item.description);
    setSelectedCollectionId(item._id);
    setUpdateCollectionStatus(true);
    setCollectionName(item.name);
    setCollectionDesc(item.description);
    setTypeResult(item.type);
  };

  const closeUpdateCollectionModal = () => {
    setUpdateCollectionStatus(false);
    setCollectionName("");
    setCollectionDesc("");
    setSelectedFile("");
    setIsFilePicked(false);
    setUpdateNameValid(true);
    setUpdateDescValid(true);
    setTypeResult("");
  };

  const updateCollection = async () => {
    try {
      if (
        !isInputValid(collectionName, setUpdateNameValid) ||
        !isInputValid(collectionDesc, setUpdateDescValid)
      ) {
        notifyError("Enter Collection Name, Description and Type");
        isInputValid(collectionName, setUpdateNameValid);
      } else {
        setUpdateBtnClicked(true);
        let formData = new FormData();
        formData.append("name", collectionName);
        formData.append("description", collectionDesc);
        formData.append("type", typeResult);
        formData.append("image", selectedFile);

        _updateCollection(selectedCollectionId, formData).then(async (res) => {
          console.log("response to update collection:", res);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            setUpdateCollectionStatus(false);
            setSelectedCollectionId("");
            setIsFilePicked(false);
            setSelectedFile("");
            getCollections();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
          closeUpdateCollectionModal();
        });
      }
      setUpdateBtnClicked(false);
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const closeDeleteCollection = () => {
    setDeleteCollectionStatus(false);
  };

  const handleDeleteCollection = (collectionId) => {
    setSelectedCollectionId(collectionId);
    setDeleteCollectionStatus(true);
  };

  const deleteCollection = async () => {
    try {
      let requestData = {
        collectionId: selectedCollectionId,
      };
      _deleteCollection(requestData).then(async (res) => {
        console.log("response to delete collection:", res);
        if (res?.status === 200) {
          notifySuccess(res.data.message);
          setDeleteCollectionStatus(false);
          setSelectedCollectionId("");
          getCollections();
        } else {
          notifyError(res.data?.message);
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleRadioChange = (e) => {
    isInputValid(e.target.value, setTypeValid);
    setTypeResult(e.target.value);
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Collection</b>
              </CCol>
              <CCol>
                <Button
                  color="success"
                  className="float-right"
                  onClick={() => handleCreateCollectionModal()}
                >
                  Add Collection
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={createCollectionStatus}
              toggle={closeCreateCollectionModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeCreateCollectionModal}>
                Create Collection
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    placeholder="Enter Collection Name"
                    id="NameInput"
                    className="mb-3"
                    name="Name"
                    onChange={(val) => {
                      isInputValid(val.target.value, setNameValid);
                      setCollectionName(val.target.value);
                    }}
                    className={` ${NameValid ? "" : "InputError"}`}
                  />
                  <p className="ErrMsg">
                    {!NameValid ? "Name is Required" : ""}
                  </p>
                  <br />
                  <Input
                    type="textarea"
                    name="Description"
                    className="mb-3"
                    placeholder="Enter Collection Description"
                    onChange={(val) => {
                      isInputValid(val.target.value, setDescValid);
                      setCollectionDesc(val.target.value);
                    }}
                    className={` ${DescValid ? "" : "InputError"}`}
                  />
                  <p id="DescErrMsg" className="ErrMsg">
                    {!DescValid ? "Description is Required" : ""}
                  </p>
                </div>
                <div className="mb-3">
                  <h6>Select Type:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="PFP"
                      // checked
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      PFP
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="Loot"
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      Loot
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="Collectible"
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      Collectible
                    </label>
                  </div>
                </div>
                <p className="ErrMsg">{!TypeValid ? "Type is Required" : ""}</p>
                <br />
                <div>
                  <input
                    type="file"
                    name="file"
                    placeholder="Upload image"
                    className="mb-3"
                    onChange={changeHandler}
                  />
                  {isFilePicked ? (
                    <div>
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        className="preview_img"
                      />
                    </div>
                  ) : (
                    <p>Select a file.</p>
                  )}
                </div>
              </ModalBody>
              <ModalFooter>
                <Button
                  color="secondary"
                  disabled={buttonClicked}
                  onClick={closeCreateCollectionModal}
                >
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={buttonClicked}
                  onClick={() => createCollection()}
                >
                  Create
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={updateCollectionStatus}
              toggle={closeUpdateCollectionModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUpdateCollectionModal}>
                Update Collection
              </ModalHeader>
              <ModalBody>
                <div className="mb-3">
                  <Input
                    value={collectionName}
                    required
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setUpdateNameValid);
                      setCollectionName(val.target.value);
                      setUpdateName(val.target.value);
                    }}
                    className={` ${UpdateNameValid ? "" : "InputError"}`}
                  />
                  <p id="NameErrMsg" className="ErrMsg">
                    {!UpdateNameValid ? "Name is Required" : ""}
                  </p>
                  <br />
                  <Input
                    type="textarea"
                    required
                    value={collectionDesc}
                    className="mb-3"
                    onChange={(val) => {
                      isInputValid(val.target.value, setUpdateDescValid);
                      setCollectionDesc(val.target.value);
                      setUpdateDesc(val.target.value);
                    }}
                    className={` ${UpdateDescValid ? "" : "InputError"}`}
                  />
                  <p id="DescErrMsg" className="ErrMsg">
                    {!UpdateDescValid ? "Description is Required" : ""}
                  </p>
                </div>
                <div className="mb-3">
                  <h6>Select Type:</h6>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault1"
                      type="radio"
                      name="flexRadioDefault"
                      value="PFP"
                      checked={typeResult === "PFP" ? true : false}
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault1">
                      PFP
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="Loot"
                      checked={typeResult === "Loot" ? true : false}
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      Loot
                    </label>
                  </div>
                  <div className="form-check">
                    <Input
                      className="form-check-input"
                      id="flexRadioDefault2"
                      type="radio"
                      name="flexRadioDefault"
                      value="Collectible"
                      checked={typeResult === "Collectible" ? true : false}
                      onClick={handleRadioChange}
                    />
                    <label className="form-check-label" for="flexRadioDefault2">
                      Collectible
                    </label>
                  </div>
                </div>
                <div>
                  <input
                    type="file"
                    name="file"
                    placeholder="Upload image"
                    className="mb-3"
                    onChange={changeHandler}
                  />
                  {isFilePicked ? (
                    <div>
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        className="preview_img mb-3"
                      />
                    </div>
                  ) : (
                    <p>Select a file.</p>
                  )}
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUpdateCollectionModal}>
                  Cancel
                </Button>
                <Button
                  color="primary"
                  disabled={updateBtnClicked}
                  onClick={() => {
                    isInputValid(UpdateName, setUpdateNameValid);
                    isInputValid(UpdateDesc, setUpdateDescValid);
                    updateCollection();
                  }}
                >
                  Update
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={deleteCollectionStatus}
              toggle={closeDeleteCollection}
              centered
              size="m"
            >
              <ModalHeader toggle={closeDeleteCollection}>
                Collection
              </ModalHeader>
              <ModalBody>
                <p>Are you sure you want to Delete this collection?</p>
              </ModalBody>
              <ModalFooter>
                <Button onClick={closeDeleteCollection}>Cancel</Button>
                <Button color="danger" onClick={deleteCollection}>
                  Delete
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <Row>
                    {collections && collections.length > 0 ? (
                      collections.map((item) => {
                        return (
                          <>
                            <div className="card collection-card">
                              <img
                                className="card-img-top card-img"
                                src={item.image_url ? item.image_url : NoImage}
                                onClick={() => handleRoute(item)}
                                alt=""
                              />
                              <div className="card-body">
                                <h4 className="card-title">{item.name}</h4>
                                <p>
                                  {item.description
                                    ? item.description
                                    : "No Description"}
                                </p>
                                <p>
                                  <b>Type: </b>
                                  {item.type ? item.type : "Type not selected"}
                                </p>
                              </div>
                              <div className="collection-btn">
                                <Button
                                  color="primary"
                                  className="collection-update-btn"
                                  onClick={() => handleUpdateCollection(item)}
                                >
                                  Update
                                </Button>
                                <Button
                                  color="danger"
                                  onClick={() =>
                                    handleDeleteCollection(item._id)
                                  }
                                >
                                  Delete
                                </Button>
                              </div>
                            </div>
                          </>
                        );
                      })
                    ) : (
                      <Row>
                        <NoContent />
                      </Row>
                    )}
                  </Row>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default Collections;
