import React, { useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import { Row } from "reactstrap";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import NoContent from "src/views/extras/NoContent";

function Items({ currentItems }) {
  return (
    <>
      <Row>
        {currentItems && currentItems.length > 0 ? (
          currentItems.map((item) => {
            return (
              <>
                <div class="card" className="collection-card">
                  <img
                    class="card-img-top"
                    className="card-img"
                    src={item.image_url ? item.image_url : NoImage}
                    alt=""
                  />
                  <div class="card-body">
                    <h4 class="card-title">{item.name}</h4>
                  </div>
                </div>
              </>
            );
          })
        ) : (
          <Row>
            <NoContent />
          </Row>
        )}
      </Row>
    </>
  );
}

function PaginatedItems({ itemsPerPage, batchData }) {
  const [currentItems, setCurrentItems] = useState(null);
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);

  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(batchData.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(batchData.length / itemsPerPage));
  }, [itemOffset, itemsPerPage]);

  const handlePageClick = (event) => {
    const newOffset = (event.selected * itemsPerPage) % batchData.length;
    setItemOffset(newOffset);
  };

  return (
    <>
      <Items currentItems={currentItems} />
      <Row className="paging-style">
        <ReactPaginate
          breakLabel="..."
          nextLabel="next >"
          onPageChange={handlePageClick}
          pageRangeDisplayed={5}
          pageCount={pageCount}
          previousLabel="< previous"
          containerClassName={"pagination"}
          subContainerClassName={"pages pagination"}
          renderOnZeroPageCount={null}
        />
      </Row>
    </>
  );
}

export default PaginatedItems;
