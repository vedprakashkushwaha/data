import React from "react";
import { CHeader, CSubheader } from "@coreui/react";
import CollectionItemImg from "src/assets/icons/images/playlist-17.png";
import { Row, Col } from "reactstrap";

const SpecialTriggers = () => {
  return (
    <>
      <div>
        <CHeader withSubheader className="test-color">
          <CSubheader className="px-3 justify-content-between">
            <div>
              <span className="collection-heading">
                Collections {">"} Collection Item {">"} NFT-special Triggers
              </span>
              <span className="plus-btn">+</span>
            </div>
          </CSubheader>
        </CHeader>
      </div>
      <div>
        <Row>
          <Col lg="12 xl-100">
            <Row>
              <Col xl="2 xl-50" md="4 box-col-6">
                <div>
                  <div className="margin-25">
                    <img alt="collection_img" src={CollectionItemImg}></img>
                  </div>
                  <h6 className="name-cntr">EXP</h6>
                  <p className="name-cntr">(points-based)</p>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default SpecialTriggers;
