import React, { useState, useEffect } from "react";
import { CCard, CCardBody, CCardHeader, CCol, CRow } from "@coreui/react";
import {
  Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Input,
  Button,
} from "reactstrap";
import { useHistory, useLocation } from "react-router-dom";
import {
  _createBatch,
  _deleteBatch,
  _getBatches,
  _updateBatch,
} from "src/api/batch";
import { notifyError, notifySuccess } from "../../utils/notification";
import NoImage from "./../../assets/icons/images/noImage.jpeg";
import { updateBreadCrumb } from "src/utils/utilities";
import NoContent from "src/views/extras/NoContent";

const GenerateImage = () => {
  const history = useHistory();
  const [createBatchStatus, setCreateBatchStatus] = useState(false);
  const [batchName, setBatchName] = useState("");
  const [selectedBatchId, setSelectedBatchId] = useState("");
  const [deleteBatchStatus, setDeleteBatchStatus] = useState(false);
  const [batches, setBatches] = useState([]);
  let location = useLocation();
  const collectionId = location ? location.state.collectionId.collectionId : "";
  const [updateBatchStatus, setUpdateBatchStatus] = useState(false);

  useEffect(() => {
    getBatches();
  }, []);

  const getBatches = async () => {
    let requestData = {
      collection_id: collectionId,
    };
    try {
      _getBatches(requestData).then(async (res) => {
        if (res && res.status === 200) {
          setBatches(res.data.data);
        } else {
          setBatches([]);
          console.log(res ? res.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleRoute = (item) => {
    let name = item.name;
    let id = item._id;

    updateBreadCrumb({ pathname: "/batchImages", name: name }, "update");

    history.push({
      pathname: "/batchImages",
      state: {
        collectionId: collectionId,
        batchId: id,
      },
    });
  };

  const createBatch = async () => {
    try {
      if (batchName === "") {
        notifyError("Enter Batch Name");
      } else {
        let requestData = {
          collection_id: collectionId,
          name: batchName,
        };
        _createBatch(requestData).then(async (res) => {
          console.log("response of create batch:", res);
          if (res.status === 201) {
            notifySuccess(res.data.message);
            setCreateBatchStatus(false);
            setBatchName("");
            getBatches();
          } else {
            console.log(res ? res.data.message : "Error!!");
          }
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const closeCreateBatchModal = () => {
    setCreateBatchStatus(false);
    setBatchName("");
  };

  const handleCreateBatchModal = () => {
    setCreateBatchStatus(true);
  };

  const closeDeleteBatch = () => {
    setDeleteBatchStatus(false);
    setSelectedBatchId("");
  };

  const handleDeleteBatch = (batchId) => {
    setSelectedBatchId(batchId);
    setDeleteBatchStatus(true);
  };

  const deleteBatch = async () => {
    try {
      let requestData = {
        batchId: selectedBatchId,
      };
      _deleteBatch(requestData).then(async (res) => {
        console.log("response to delete batch:", res);
        if (res.status === 200) {
          notifySuccess(res.data.message);
          setDeleteBatchStatus(false);
          setSelectedBatchId("");
          getBatches();
        } else {
          console.log(res ? res.data.data.message : "Error!!");
        }
      });
    } catch (error) {
      console.log("Error:", error);
    }
  };

  const handleUpdateBatch = (item) => {
    setSelectedBatchId(item._id);
    setUpdateBatchStatus(true);
    setBatchName(item.name);
  };

  const closeUpdateBatchModal = () => {
    setUpdateBatchStatus(false);
    setBatchName("");
  };

  const updateBatch = async () => {
    try {
      if (batchName === "") {
        notifyError("Enter the Batch Name");
      } else {
        let requestData = {
          name: batchName,
        };
        _updateBatch(selectedBatchId, requestData).then(async (res) => {
          console.log("response to update batch:", res);
          if (res.status === 200) {
            notifySuccess(res.data.message);
            setUpdateBatchStatus(false);
            setSelectedBatchId("");
            getBatches();
          } else {
            console.log(res ? res.data.data.message : "Error!!");
          }
        });
      }
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            <CRow>
              <CCol xs="6">
                <b>Image Batches</b>
              </CCol>
              <CCol>
                <Button
                  color="success"
                  className="float-right"
                  onClick={() => handleCreateBatchModal()}
                >
                  Create Batch
                </Button>
              </CCol>
            </CRow>
          </CCardHeader>
          <CCardBody>
            <Modal
              isOpen={createBatchStatus}
              toggle={closeCreateBatchModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeCreateBatchModal}>
                Create Batch
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    placeholder="Enter Batch Name"
                    onChange={(val) => setBatchName(val.target.value)}
                  />
                </div>
                <br />
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeCreateBatchModal}>
                  Cancel
                </Button>
                <Button color="primary" onClick={() => createBatch()}>
                  Create
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={deleteBatchStatus}
              toggle={closeDeleteBatch}
              centered
              size="m"
            >
              <ModalHeader toggle={closeDeleteBatch}>Delete Batch</ModalHeader>
              <ModalBody>
                <p>Are you sure you want to Delete this batch?</p>
              </ModalBody>
              <ModalFooter>
                <Button onClick={closeDeleteBatch}>Cancel</Button>
                <Button color="danger" onClick={deleteBatch}>
                  Delete
                </Button>
              </ModalFooter>
            </Modal>
            <Modal
              isOpen={updateBatchStatus}
              toggle={closeUpdateBatchModal}
              centered
              size="m"
            >
              <ModalHeader toggle={closeUpdateBatchModal}>
                Update Batch Name
              </ModalHeader>
              <ModalBody>
                <div>
                  <Input
                    value={batchName}
                    onChange={(val) => setBatchName(val.target.value)}
                  />
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="secondary" onClick={closeUpdateBatchModal}>
                  Cancel
                </Button>
                <Button color="primary" onClick={() => updateBatch()}>
                  Update
                </Button>
              </ModalFooter>
            </Modal>
            <div>
              <Row>
                <Col lg="12 xl-100">
                  <Row>
                    {batches && batches.length > 0 ? (
                      batches.map((item) => {
                        return (
                          <>
                            <div class="card" className="collection-card">
                              <img
                                class="card-img-top"
                                className="card-img"
                                src={item.image_url ? item.image_url : NoImage}
                                onClick={() => handleRoute(item)}
                                alt=""
                              />
                              <div class="card-body">
                                <h4 class="card-title">{item.name}</h4>
                              </div>
                              <div className="collection-btn">
                                <Button
                                  color="primary"
                                  className="collection-update-btn"
                                  onClick={() => handleUpdateBatch(item)}
                                >
                                  Update
                                </Button>
                                <Button
                                  color="danger"
                                  onClick={() => handleDeleteBatch(item._id)}
                                >
                                  Delete
                                </Button>
                              </div>
                            </div>
                          </>
                        );
                      })
                    ) : (
                      <Row>
                        <NoContent />
                      </Row>
                    )}
                  </Row>
                </Col>
              </Row>
            </div>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default GenerateImage;
