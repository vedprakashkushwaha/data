import React from "react";
import NoData from "src/assets/icons/images/NoData.png";

const NoContent = () => {
  return (
    <>
      <div>
        <div className="card NoData-card">
          <img
            className="card-img-top NoData-img"
            src={NoData}
            alt="No Data Found !!"
          />
        </div>
      </div>
    </>
  );
};

export default NoContent;
