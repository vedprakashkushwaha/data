import {
  USER_REGISTRATION_SUCCESS,
  USER_REGISTRATION_FAIL,
} from "../../redux/constants/action-types";
import setAuthToken from "src/utils/setAuthToken";

export const registerSuccess = () => async (dispatch) => {
  if (localStorage.getItem("loggedUserToken")) {
    setAuthToken(localStorage.getItem("loggedUserToken"));
  }
  dispatch({
    type: USER_REGISTRATION_SUCCESS,
  });
};

export const logOut = () => (dispatch) => {
  dispatch({
    type: USER_REGISTRATION_FAIL,
  });
};
