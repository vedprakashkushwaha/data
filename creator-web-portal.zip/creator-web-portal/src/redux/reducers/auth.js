import {
  USER_REGISTRATION_SUCCESS,
  USER_REGISTRATION_FAIL,
} from "../../redux/constants/action-types";

const initialState = {
  isAuthenticated: false,
};

function auth(state = initialState, action) {
  switch (action.type) {
    case USER_REGISTRATION_SUCCESS:
      return {
        ...state,
        isAuthenticated: true,
      };
    case USER_REGISTRATION_FAIL:
      return {
        ...state,
        isAuthenticated: false,
      };
    default: {
      return state;
    }
  }
}

export default auth;
