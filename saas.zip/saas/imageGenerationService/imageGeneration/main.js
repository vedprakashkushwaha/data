const fs = require("fs");
const mongoose = require("mongoose");
const ImageBatchModel = mongoose.model("imageBatch")
const { createCanvas, loadImage } = require("canvas");
const console = require("console");
const { format, rarity } = require("./config.js");
const canvas = createCanvas(format.width, format.height);
const ctx = canvas.getContext("2d");
const { getLayersVariationOrders, getVariationElements } = require("../handlers/dbHandler")
const { getS3SingleImage, uploadMergeImage } = require("../handlers/commonHandler")
const { updateImageBatchStatus, createImageBatchKey, createImageMetadata } = require("../handlers/dbHandler")
const io = require("../handlers/socket");
const cacheHandler = require('../handlers/cache');

if (!process.env.PWD) {
  process.env.PWD = process.cwd();
}

const buildDir = `${process.env.PWD}/images`;
const metDataFile = '_metadata.json';

let metadata = [];
let attributes = [];
let hash = [];
let decodedHash = [];
const Exists = new Map();
let progressImages = 0;

// const addRarity = _str => {
//   let itemRarity;

//   rarity.forEach((r) => {
//     if (_str.includes(r.key)) {
//       itemRarity = r.val;
//     }
//   });

//   return itemRarity;
// };

// const cleanName = _str => {
//   let name = _str.slice(0, -4);
//   rarity.forEach((r) => {
//     name = name.replace(r.key, "");
//   });
//   return name;
// };

const layersSetup = async (layersOrder) => {
  try {
    let layers = [];
    const length = layersOrder.length;
    for (let index = 0; index < length; index++) {

      let data = {
        id: index,
        name: layersOrder[index].name,
        elements: await getVariationElements(layersOrder[index]),
        position: { x: 0, y: 0 },
        size: { width: format.width, height: format.height },
        number: layersOrder[index].number
      }

      layers.push(data)
    }

    return layers;
  } catch (err) {
    console.log("Err: ", err)
  }
};

const builfParent = async () => {
  if (!fs.existsSync(buildDir)) {
    fs.mkdirSync(buildDir, { recursive: true });
  }
}
const buildSetup = async (number, newImageGen) => {
  await builfParent()
  const _dir = `${buildDir}/${newImageGen._id}`
  if (fs.existsSync(_dir)) {
    fs.rmdirSync(_dir, { recursive: true });
  }
  let status;
  try {
    status = fs.mkdirSync(_dir, { recursive: true });
  } catch(err) {
    console.log("Unable to create directory! ", err);
  }
  return status;
};

const saveLayer = async (_canvas, _edition, data) => {
  try {
    const filename = `${buildDir}/${data._id}/${data.name_prefix}${data.numbering_offset + _edition}.png`;
    fs.writeFileSync(filename, _canvas.toBuffer("image/png"));
  } catch (Error) {
    console.log("Save Layer: ", Error)
  }

};

const addMetadata = _edition => {
  let dateTime = Date.now();
  let tempMetadata = {
    hash: hash.join(""),
    decodedHash: decodedHash,
    edition: _edition,
    date: dateTime,
    attributes: attributes,
  };
  metadata.push(tempMetadata);
  attributes = [];
  hash = [];
  decodedHash = [];
};

const addAttributes = (_element, _layer) => {
  const element_id = _element.index
  const layer_id = _layer.id

  let tempAttr = {
    // id: element_id,
    trait_type: _layer.name,
    value: _element.name,
    rarity: _element.rarity,
    imageKey: _element.imageKey
  };
  attributes.push(tempAttr);
  hash.push(layer_id);
  hash.push(element_id);
  decodedHash.push({ [layer_id]: element_id });
};

const drawLayer = async (_layer, _edition, data) => {
  try {
    const rand = Math.random();
    let element =
      _layer.elements[Math.floor(rand * _layer.number)] ? _layer.elements[Math.floor(rand * _layer.number)] : null;

    const updatedElement = await getS3SingleImage(element);
    let image;
    if (element) {
      addAttributes(element, _layer);

      const image_url = await updatedElement.image_url

      // const image = await loadImage(image_url);
      if (image_url) {
        image = await loading(image_url);
      } else {
        console.log("Invalid Image URL: ", updatedElement)
      }


      // ctx.drawImage(
      //   image,
      //   _layer.position.x,
      //   _layer.position.y,
      //   _layer.size.width,
      //   _layer.size.height
      // );
      drawimg(image, _layer)
      saveLayer(canvas, _edition, data);
    }
  } catch (err) {
    console.log("Draw Layer ", err);
  }
};


const loading = async (image_url) => {
  try {
    const image = await loadImage(image_url);

    return image;
  } catch (err) {
    console.log("load img ", err);
  }
}

const drawimg = async (image, _layer) => {
  try {
    ctx.drawImage(
      image,
      _layer.position.x,
      _layer.position.y,
      _layer.size.width,
      _layer.size.height
    );
  } catch (err) {
    console.log("Draw img ", err);
  }
}

const createFiles = async (totalImages, data) => {
  try {
    updateImageBatchStatus(data._id, "processing");

    const layerData = await getLayersVariationOrders(data.collection_id);

    const layers = await layersSetup(layerData);  // layersOrder order has name and count of variation 
    let numDupes = 0;

    let filePath = "";
    for (let i = 1; i <= totalImages; i++) {

      filePath = `${buildDir}/${data._id}/${data.name_prefix}${data.numbering_offset + i}.png`;
      console.log("Generating Image " + filePath);

      for (let j = 0; j < layers.length; j++) {
        await drawLayer(layers[j], i, data);
      }

      let key = hash.toString();
      if (Exists.has(key)) {
        console.log(
          `Duplicate creation for edition ${i}. Same as edition ${Exists.get(
            key
          )}`
        );
        numDupes++;
        if (numDupes > totalImages) break; //prevents infinite loop if no more unique items can be created
        i--;

      } else {
        Exists.set(key, i);
        await uploadFileToS3(filePath, data, i)
        addMetadata(i);
        removeFile(filePath)
        const batch_id = data._id;
        sendProgress(totalImages, batch_id)
        console.log("Creating edition " + i);
      }
    }
    const remove_dirPath = `${buildDir}/${data._id}`
    removeFolder(remove_dirPath);
    await updateImageBatchStatus(data._id, "completed");
    progressImages = 0;
    return true;
  }
  catch (err) {
    console.log("Create File ", err);
  }
};

const removeFile = (_dir) => {
  if (fs.existsSync(_dir)) {
    fs.rmdirSync(_dir, { recursive: true });
  }
}

const removeFolder = (_dir) => {
  if (fs.existsSync(_dir)) {
    fs.rmdirSync(_dir, { recursive: true });
  }
}

const uploadFileToS3 = async (filePath, data, i) => {
  const fileName = `${data.name_prefix}${data.numbering_offset + i}`;
  const result = await uploadMergeImage(filePath, fileName)

  // create metadata 
  const imageMetadata = {
    imageBatch_id: data._id,
    // imageBatchkey_id: imageBatchKey._id,
    attributes: attributes
  }
  const metadata = await createImageMetadata(imageMetadata)

  const imgaeBatchData = {
    imageBatch_id: data._id,
    name: fileName,
    imageKey: result.key,
    metadata: metadata._id
  }
  await createImageBatchKey(imgaeBatchData)
}

const sendProgress = async function (number, batch_id) {
  try {
    progressImages += 1;
    const progress = progressImages / parseInt(number) * 100;
    cacheHandler.setData(batch_id, JSON.stringify({progress: Math.ceil(progress)}));
    console.log("batch_id >>", batch_id);
    //comment socket
    // cacheHandler.setData(batch_id, JSON.stringify(socket.id));
    const socket_id = await cacheHandler.getData(batch_id);
    // sending progress
    io.to(socket_id).emit('progress', progress);
  } catch (e) {
    console.log("send progress:", e);
  }
}

module.exports = { buildSetup, createFiles };
