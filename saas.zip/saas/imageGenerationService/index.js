require("../common/db");
const mongoose = require("mongoose")
const cron = require('node-cron');
const { buildSetup, createFiles } = require("./imageGeneration/main.js");
const { checkNewImageGenerationEntry } = require("./handlers/dbHandler")
const Queue = require('bull');
const express = require('express');
const app = express();
const io = require('./handlers/socket');
const errorMessages = require('../api/config/errorMessages.json');
const Notification = mongoose.model('notification');

const mergeImageQueue = new Queue('mergeImageQueue', {
  limiter: {
    max: 10,
    duration: 1000,
  },
  defaultJobOptions: {
    attempts: 0,
    backoff: {
      type: 'fixed',
      delay: 10000,
    },
  },
});

// // export socket.io to a global
// app.set('socketio', io);

cron.schedule('* * * * * *', async () => {
  const newImageGen = await checkNewImageGenerationEntry();

  if (Object.keys(newImageGen).length != 0) {
    const number = newImageGen.number
    console.log("newImageGen >>>", newImageGen);

    // export socket.io to a global   
    app.set('socketio', io);

    const job = await mergeImageQueue.add({
      number, newImageGen
    });
  }
});

mergeImageQueue.process(async (params) => {
  try {
    (async () => {
      const setupStatus = await buildSetup(params.data.number, params.data.newImageGen);
      const notification = {
        text: errorMessages.unableToCreateFiles,
        type: 'FAILED_IMAGE_GENERATION',
        image_batch_id: params.data.newImageGen._id,
      }
      if(setupStatus) {
        const fileCreation = await createFiles(params.data.number, params.data.newImageGen);
        if(!fileCreation) {
          await Notification.create(notification);
        }
      } else {
        await Notification.create(notification);
      }
    })();
  } catch (error) {
    console.log("Queue failed: ", error);
  }
});