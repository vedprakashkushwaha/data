
module.exports.getGivenSecondBeforeDate = (second) => {

    const currentDate = new Date();
    const milliseconds = Number(second) * 1000;
    
    let time = new Date(currentDate.getTime() - milliseconds);

    return time
}