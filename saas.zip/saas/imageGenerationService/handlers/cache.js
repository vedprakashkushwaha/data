const cacheHandler = {};
const redis = require("redis");

let client = null;
// const clientConfig = {
//     host: '127.0.0.1',
//     port: '6379'
// }
cacheHandler.getClient = async function () {
    try {
        if (!client) {
            client = redis.createClient();
            client.on('connect', () => {
                console.log('Redis server connected: ');
            });
            return client;
        } else {
            return client;
        }
    } catch (err) {
        console.log("Redis Error: ", err);
    }
}

cacheHandler.getData = async function (key) {
    return new Promise(async (resolve, reject) => {
        try {
            if (!key) {
                return reject("missing key");
            }
            let data;
            const client = await cacheHandler.getClient();
            client.get(key, (err, reply) => {
                if (err) {
                    reject(err);
                }
                data = reply ? JSON.parse(reply) : {};
                return resolve(data);
            });
        } catch (err) {
            console.log("err1: ", err);
        }
    });
};


cacheHandler.setData = async function (key, data) {
    try {
        if (!key || !data) {
            throw new Error("missing params");
        }
        const client = await cacheHandler.getClient();
        client.set(key, data, (err, reply) => {
            console.log('Data set into cache: ', key, reply);
        });
    } catch (error) {
        throw (error.toString());
    }
};


module.exports = cacheHandler;