const mongoose = require("mongoose")
const ImageBatchModel = mongoose.model('imageBatch');
const NFTLayerVariantModel = mongoose.model('nftlayervariant');
const CollectionModel = mongoose.model('collection');
const ImageBatchKeyModel = mongoose.model('imageBatchKey');
const MetadataModel = mongoose.model('imageMetadata');
const { getGivenSecondBeforeDate } = require("./dateTimeHandler")

module.exports.checkNewImageGenerationEntry = async () => {
    const secondsBeforeTime = getGivenSecondBeforeDate(30000)

    let data = await ImageBatchModel.findOne({ status: "initiated", updatedAt: { $gte: secondsBeforeTime } }).lean()

    return data
}


module.exports.getLayersVariationOrders = async (collection_id) => {
    let layerVariationData = await CollectionModel.aggregate([
        { $match: { _id: mongoose.Types.ObjectId(collection_id), } },
        {
            $lookup: {
                from: "nftlayers",
                localField: "_id",
                foreignField: "collection_id",
                as: "layer"
            }
        }, {
            $unwind: {
                path: "$layer",
                preserveNullAndEmptyArrays: true
            }
        }, {
            $lookup: {
                from: "nftlayervariants",
                localField: "layer._id",
                foreignField: "layer_id",
                as: "layer.variations",
            }
        },
        { $sort: { "layer.order": 1 } },
        {
            $group: {
                _id: null,
                layer: { $push: { "layer_id": "$layer._id", "name": "$layer.name", "order": "$layer.order", "number": { $size: "$layer.variations" } } },
            },
        },
    ]);

    return layerVariationData[0].layer;
}


module.exports.getVariationElements = async (layerObj) => {

    let data = await NFTLayerVariantModel.find({ layer_id: layerObj.layer_id }).select("_id name images rarity form_nft_when_detached").lean()

    data.map((item, index) => {
        return (
            item["imageKey"] = item.images.filter(i => i.type === "Combined")[0].imageKey,
            item["index"] = index,
            delete item.images
        )
    });

    return data
}

module.exports.updateImageBatchStatus = async (_id, status) => {

    await ImageBatchModel.findOneAndUpdate({ _id: _id }, { $set: { status: status } });

    return
}

module.exports.createImageBatchKey = async (requestData) => {

    const data = await ImageBatchKeyModel.create(requestData);

    return data;
}

module.exports.createImageMetadata = async (data) => {

    const result = await MetadataModel.create(data);

    return result;
}