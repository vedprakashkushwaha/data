const socket = require('socket.io');
const express = require('express');
const app = express();
http = require('http').Server(app);
http.listen(process.env.SOCKETS_PORT, "0.0.0.0");
const cacheHandler = require('./cache');


const io = socket(http, {
  cors: {
    origin: '*',
    methods: ["GET", "POST"]
  }
});

// const batchSocketData = {}

// socket connection
io.on('connection', (socket) => {
  try {
    console.log("Socket Connected");
    const qtd = socket.client.conn.server.clientsCount;
    
    socket.emit('asking_for_batch_id');
    
    socket.on('batch_id', (batch_id) => {
      
      // batchSocketData[batch_id] = socket.id;
      //comment socket
     // cacheHandler.setData(batch_id, JSON.stringify(socket.id));
    });
    
    socket.on('disconnect', () => {
      io.emit('disconnected user', qtd - 1);
    });
  } catch (err) {
    console.log("error: ", err);
  };
});

module.exports = io;