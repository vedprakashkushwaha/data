const fs = require('fs');
const util = require('util');
const unlinkFile = util.promisify(fs.unlink)
const { uploadMergedFile, getFileStream } = require('../../common/s3')


async function getS3SingleImage(element) {
    try {
        let key = element.imageKey

        if (element.image_url) {
            return element
        } else {
            const image = key ? await getFileStream(key) : ""
            element['image_url'] = image
            return element
        }
    } catch (err) {
        console.log(err)
    }
}

exports.getS3SingleImage = getS3SingleImage;


async function uploadImageToS3(file, name) {
    // uploading file to S3
    const result = await uploadMergedFile(file, name);

    // deleting file from local
    // const path = file.path
    // await unlinkFile(path)

    return result
}

exports.uploadImageToS3 = uploadImageToS3;


async function uploadMergeImage(filePath, name) {
    try {
        const fileContent = fs.readFileSync(filePath);
        const result = await uploadImageToS3(fileContent, name);

        return result;
    } catch (Error) {
        console.log("Save Layer: ", Error)
    }

}

exports.uploadMergeImage = uploadMergeImage;
