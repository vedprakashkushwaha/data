const mongoose = require("mongoose")

const imageMetadata = mongoose.Schema({
    imageBatch_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'imageBatch',
        required: true,
    },
    attributes: [{
        trait_type: {
            type: String,
            required: true,
            _id: false
        },
        value: {
            type: String,
            required: true,
            _id: false
        },
        rarity: {
            type: String,
            required: false,
            _id: false
        },
        imageKey:{
            type: String,
            required: false,
        }
    },{required:false}],
    createdAt: {
        type: Date,
        default: Date.now(),
        required: false
    }
},{strict: false})

mongoose.model("imageMetadata", imageMetadata);