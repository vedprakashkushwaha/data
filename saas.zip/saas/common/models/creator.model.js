const mongoose = require('mongoose');

const CreatorSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: false,
        trim: true
    },
    lastName: {
        type: String,
        required: false,
        trim: true
    },
    email: {
        type: String,
        required: false,
        trim: true
    },
    googleId: {
        type: String,
        required: true,
        trim: true
    },
    isVerified: {
        type: Boolean,
        require: false,
        default: false
    },
    createdAt: {
        type: Date,
        required: false,
        default: Date.now()
    },
    updatedAt: {
        type: Date,
        required: false,
        default: Date.now()
    },
});

mongoose.model('creator', CreatorSchema);