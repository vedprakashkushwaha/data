const mongoose = require("mongoose")

const imageBatchKey = mongoose.Schema({
    imageBatch_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'imageBatch',
        required: true
    },
    name: {
        type: String,
        required: false
    },
    imageKey: {
        type: String,
        required: false
    },
    metadata: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'imageMetadata',
        required: true,
    },
    num_editions:{
        type: Number,
        required: false
    },
    createdAt: {
        type: Date,
        default: Date.now(),
        required: false
    }
})

mongoose.model("imageBatchKey", imageBatchKey);