const mongoose = require('mongoose');

const NFTLayerVariantSchema = new mongoose.Schema({
    numeric_id: {
        type: Number,
        required: false
    },
    name: {
        type: String,
        required: true,
    },
    images: {
        type: Array,
        required: false,
    },
    rarity: {
        type: String,
        required: true,
    },
    layer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'nftlayer',
        required: true,
    },
    metadataCID: {
        type: String,
        required: false
    },
    form_nft_when_detached: {
        type: Boolean,
        required: false,
        default: true
    },
    createdAt: {
        type: Date,
        required: false,
        default: Date.now()
    }
});

mongoose.model('nftlayervariant', NFTLayerVariantSchema);