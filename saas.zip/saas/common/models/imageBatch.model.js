const mongoose = require("mongoose")

const imageBatch = new mongoose.Schema({
    collection_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "collection",
        required: true
    },
    name: {
        type: String,
        required: true
    },
    status: {
        type: String,
        required: true,
        default: "pending",
        enum: {
            values: ["pending", "initiated", "processing", "completed"],
            message: "{VALUE} is Invalid Status."
        }
    },
    number: {
        type: Number,
        required: false
    },
    name_prefix: {
        type: String,
        required: false
    },
    numbering_offset: {
        type: Number,
        required: false
    },
    createdAt: {
        type: Date,
        required: false,
        default: new Date()
    },
    updatedAt: {
        type: Date,
        required: false,
        default: new Date()
    }
})

mongoose.model("imageBatch", imageBatch);