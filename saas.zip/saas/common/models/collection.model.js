const mongoose = require('mongoose');

const collectionSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    imageKey: {
        type: String,
        required: false,
    },
    creator_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'creator',
        required: false,
    },
    collaborators: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'creator',
        required: false,
    }],
    image_width:{
        type: Number,
        required: false,
        default: 250
    },
    image_height:{
        type: Number,
        required: false,
        default: 250
    },
    type: {
        type: String,
        required: true,
        enum: {
            values: ["PFP", "Loot", "Collectible"],
            message: "{VALUE} is not supported",
        },
    },
    createdAt: {
        type: Date,
        required: false,
        default: Date.now()
    }
});

mongoose.model('collection', collectionSchema);