const mongoose = require('mongoose');

const NFTLayerSchema = new mongoose.Schema({
    numeric_id: {
        type: Number,
        required: false
    },
    name: {
        type: String,
        required: true,
    },
    imageKey: {
        type: String,
        required: false,
    },
    collection_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'collection',
        required: true,
    },
    form_nft_when_detached: {
        type: Boolean,
        required: true
    },
    order: {
        type: Number,
        required: true,
    },
    createdAt: {
        type: Date,
        required: false,
        default: Date.now()
    },
});

mongoose.model('nftlayer', NFTLayerSchema);