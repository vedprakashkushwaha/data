const mongoose = require('mongoose');
const NotificationSchema = new mongoose.Schema({
    text: {
        type: String,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    image_number: {
        type: Number,
        required: false,
    },
    image_batch_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'imageBatch',
        required: false,
    },
    createdAt: {
        type: Date,
        required: false,
        default: Date.now()
    },
});
mongoose.model('notification', NotificationSchema);