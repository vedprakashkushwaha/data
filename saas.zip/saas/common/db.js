require('dotenv').config();
const mongoose = require('mongoose');
const dburl = process.env.DBURL;
console.log("dburl >>", dburl)
mongoose.connect(dburl);

// CONNECTION EVENTS
mongoose.connection.on('connected', function () {
  console.log('Mongoose connected to ' + dburl);
});
mongoose.connection.on('error', function (err) {
  console.log('Mongoose connection error: ' + err);

});
mongoose.connection.on('disconnected', function () {
  console.log('Mongoose disconnected');
});

// CAPTURE APP TERMINATION / RESTART EVENTS
function gracefulShutdown(msg, callback) {
  mongoose.connection.close(function () {
    console.log('Mongoose disconnected through ' + msg);
    callback();
  });
}

// For nodemon restarts
process.once('SIGUSR2', function () {
  gracefulShutdown('nodemon restart', function () {
    process.kill(process.pid, 'SIGUSR2');
  });
});
// For app termination
process.on('SIGINT', function () {
  gracefulShutdown('App termination (SIGINT)', function () {
    process.exit(0);
  });
});
// For app termination
process.on('SIGTERM', function () {
  gracefulShutdown('App termination (SIGTERM)', function () {
    process.exit(0);
  });
});

// BRING IN YOUR SCHEMAS & MODELS

require('./models/creator.model')
require('./models/collection.model')
require('./models/layer.model')
require('./models/variant.model')
require('./models/imageBatch.model')
require('./models/imageBatchKeys.model')
require('./models/metadata.model')
require('./models/notification.model')