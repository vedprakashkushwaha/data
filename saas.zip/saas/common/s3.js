require('dotenv').config()
const fs = require('fs');
const S3 = require('aws-sdk/clients/s3');

const bucketName = process.env.AWS_BUCKET_NAME
const region = process.env.AWS_REGION
const accessKeyId = process.env.AWS_ACCESS_KEY
const secretAccessKey = process.env.AWS_SECRET_KEY

const s3 = new S3({
    secretAccessKey,
    accessKeyId,
    region
})

function uploadFile(file, path = "blockcolabs", fileName = "test.png") {
    const fileStream = fs.createReadStream(file.path);
    const uploadParams = {
        Bucket: bucketName,
        Body: fileStream,
        ContentType: file.mimetype,
        // ACL: 'public-read',
        Key: `blockcolabs/image-${Date.now()}.jpeg`
    }
    return s3.upload(uploadParams).promise()
}

exports.uploadFile = uploadFile;

function getFileStream(fileKey) {
    const downloadParams = {
        Key: fileKey,
        Bucket: bucketName
    }
    // return s3.getObject(downloadParams).createReadStream()
    const readSignedUrl = new Promise((resolve, reject) => {
        s3.getObject(downloadParams, (err, data) => {
            if (err) reject(err)
            else resolve(data.Body)
        })
    })
    return readSignedUrl
}
exports.getFileStream = getFileStream;

async function getSignedUrl(key) {
    var params = {
        Bucket: bucketName,
        Key: key,
        // ContentType: 'application/json',
        Expires: 600                // expires in 10 mins
    }

    const readSignedUrl = new Promise((resolve, reject) => {
        s3.getSignedUrl('getObject', params, (err, url) => {
            if (err) reject(err)
            else resolve(url)
        })
    })
    return readSignedUrl
}

exports.getSignedUrl = getSignedUrl;


function uploadMergedFile(file, name) {
    // const fileStream = fs.createReadStream(file.path);
    const uploadParams = {
        Bucket: bucketName,
        Body: file,
        ContentType: "image/png",
        // ACL: 'public-read',
        Key: `blockcolabs/${name}.png`
    }
    return s3.upload(uploadParams).promise()
}
exports.uploadMergedFile = uploadMergedFile;
