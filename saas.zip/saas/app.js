require('./common/db');
const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const routes = require('./api/routes/routes');
var cors = require('cors')

var corsOptions = {
  origin: ['http://localhost:3000'],
  optionsSuccessStatus: 200,
  methods: "GET, PUT, POST, PATCH, DELETE"
}
app.use(cors(corsOptions));

// Define the port to run on
app.use(bodyParser.urlencoded({
  extended: 'true'
}));
app.use(bodyParser.json());

// app.listen(3003, "0.0.0.0");
app.listen(process.env.API_PORT, function () {
  console.log("Server Started. App running on port 8000");
});

// CORS Middleware
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", '*');
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
  next();
});

// routing
app.use('/api/v1', routes);

// Set static directory before defining routes
app.use(express.static(path.join(__dirname, 'public')));