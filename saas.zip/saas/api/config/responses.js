const appConstants = require('./appConstants.json');

exports.actionCompleteResponse = (res, msg, data, status = appConstants.DEFAULT_SUCCESS_STATUS) => {
	const response = {
		message: msg || appConstants.EXECUTEDSUCCESS,
		success: appConstants.ACTIONCOMPLETE,
		data: data || {},
	};
	res.status(status).json(response);
};

exports.sendError = (res, err = appConstants.ERRORINEXECUTION, data, status = appConstants.INTERNAL_SERVER_ERROR_STATUS_CODE) => {
	let errMsg = err.toString();
	errMsg = errMsg.replace(appConstants.ERROR, '');
	errMsg = errMsg.split('Error:').join('');
	errMsg = errMsg.trim();

	const response = {
		message: errMsg,
		success: appConstants.ERRORINEXECUTION,
		data: data || {},
	};

	res.status(status).json(response);
};

exports.noDataFound = (res, msg, data, status = appConstants.NO_DATA_FOUND_STATUS_CODE) => {
	const response = {
		message: msg || appConstants.EXECUTEDSUCCESS,
		success: appConstants.ACTIONCOMPLETE,
		data: data || {},
	};
	res.status(status).json(response);
};