const express = require('express');
const router = express.Router();
const collectionController = require('../controllers/collection.controller');
// const livingNFTController = require('../controllers/livingNFT.controller');
const NFTLayerController = require('../controllers/layer.controller');
const NFTLayerVariantController = require('../controllers/variant.controller');
const creatorController = require('../controllers/creator.controller');
const isAuthorizedMiddleware = require("../../auth/isAuthorized");
const imageBatchController = require("../controllers/imageBatch.controller")
const imageCreationsController = require("../controllers/imageCreation.controller")

const multer = require("multer");
const upload = multer({ dest: 'uploads/' })


// ***********************************************************************************
//            Public Route Starts
// ***********************************************************************************
router
  .route('/creators')
  .post(creatorController.googleLogin)


// ***********************************************************************************
//            Public Route Ends
// ***********************************************************************************

// ***********************************************************************************
//            Private Route Starts
// ***********************************************************************************
router
  .route('/collections')
  .post(isAuthorizedMiddleware, upload.single('image'), collectionController.create)

router
  .route('/collections/:collection_id?')
  .get(isAuthorizedMiddleware, collectionController.getCollections)

router
  .route('/collections/:collection_id')
  .patch(isAuthorizedMiddleware, upload.single('image'), collectionController.updateCollection)

router
  .route('/collections/:collection_id')
  .delete(isAuthorizedMiddleware, collectionController.deleteCollection)

router
  .route('/collections/collaborator')
  .post(isAuthorizedMiddleware, collectionController.addCollaborator)

router
  .route('/collections/collaborator/:collection_id')
  .delete(isAuthorizedMiddleware, collectionController.removeCollaborator)

// router
//   .route('/create-living-nft')
//   .post(isAuthorizedMiddleware, livingNFTController.create)

// router
//   .route('/get-nft-by-collection-id')
//   .get(isAuthorizedMiddleware, livingNFTController.getNftByCollectionId)

router
  .route('/layers')
  .post(isAuthorizedMiddleware, NFTLayerController.create)

router
  .route('/layers/:layer_id')
  .patch(isAuthorizedMiddleware, NFTLayerController.updateLayer)

router
  .route('/layers/:layer_id/image')
  .patch(isAuthorizedMiddleware, upload.single('image'), NFTLayerController.updateLayerImage)

router
  .route('/layers/:layer_id')
  .delete(isAuthorizedMiddleware, NFTLayerController.deleteLayer)

router
  .route('/layers/:layer_id?')
  .get(isAuthorizedMiddleware, NFTLayerController.getLayers)

router
  .route('/variations')
  .post(isAuthorizedMiddleware, NFTLayerVariantController.create)

router
  .route('/variations/:variation_id')
  .patch(isAuthorizedMiddleware, NFTLayerVariantController.updateVariant)

router
  .route('/variations/:variation_id/image/:type')
  .patch(isAuthorizedMiddleware, upload.single('image'), NFTLayerVariantController.updateVariationImage)

router
  .route('/variations/:variation_id')
  .delete(isAuthorizedMiddleware, NFTLayerVariantController.deleteVariant)

router
  .route('/variations/:variation_id?')
  .get(isAuthorizedMiddleware, NFTLayerVariantController.getVariations)

router
  .route('/creators')
  .get(isAuthorizedMiddleware, creatorController.getCreatorDetail)

router
  .route('/creators/human-readable-id/:human_readable_id')
  .get(isAuthorizedMiddleware, creatorController.getCreatorDetailById)

router
  .route('/image-batches/')
  .post(isAuthorizedMiddleware, imageBatchController.createBatch)

router
  .route('/image-batches/:image_batch_id?')
  .get(isAuthorizedMiddleware, imageBatchController.getBatches)

router
  .route('/image-batches/:image_batch_id?')
  .delete(isAuthorizedMiddleware, imageBatchController.deleteBatch)

router
  .route('/image-batches/:image_batch_id/generation')
  .patch(isAuthorizedMiddleware, imageBatchController.generateImage)

router
  .route('/image-batches/:image_batch_id')
  .patch(isAuthorizedMiddleware, imageBatchController.updateImageBatch)

router
  .route('/images/:image_id?')
  .get(isAuthorizedMiddleware, imageCreationsController.getImages)

router
  .route('/images/:image_id')
  .delete(isAuthorizedMiddleware, imageCreationsController.deleteImage)

router
  .route('/image-generation-status/:image_batch_id')
  .get(isAuthorizedMiddleware, imageBatchController.imageGenerationStatus)

router.route('/images')
  .post(isAuthorizedMiddleware, imageCreationsController.createCollectibleImage)

router
  .route('/images/:image_id')
  .patch(isAuthorizedMiddleware, imageCreationsController.updateImageInfo)

router
  .route('/images/:image_id/image')
  .patch(isAuthorizedMiddleware ,upload.single('image'), imageCreationsController.updateImage)

// router
//   .route('images[/:image_id]?batch-image-id=:batch_image_id&offset=:offset&max-entries=:max_entries')
//   .get(isAuthorizedMiddleware, imageCreationsController.getCollectibleImage)



// router
//   .route('/users/search/email')
//   .get(isAuthorizedMiddleware, creatorController.searchCreatorForCollab)


// ***********************************************************************************
//            Private Route Ends
// ***********************************************************************************

module.exports = router;