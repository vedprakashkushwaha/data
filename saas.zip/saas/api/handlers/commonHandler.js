const fs = require('fs');
const util = require('util');
const unlinkFile = util.promisify(fs.unlink)
const { uploadFile, getSignedUrl } = require('../../common/s3')

async function getS3Images(array) {
    try {
        const length = array.length

        for (let i = 0; i < length; i++) {
            let key = array[i].imageKey
            const image = key ? await getSignedUrl(key) : "";
            array[i]['image_url'] = image;
            delete array[i]['imageKey']
        }

        return array
    } catch (err) {
        console.log("Get S3 Image: ", err);
    }
}

exports.getS3Images = getS3Images;


async function uploadImageToS3(file) {
    // uploading file to S3
    const result = await uploadFile(file);

    // deleting file from local
    const path = file.path
    await unlinkFile(path)

    return result
}

exports.uploadImageToS3 = uploadImageToS3;


async function getS3VariationsImages(array) {
    const length = array.length

    for (let i = 0; i < length; i++) {
        const imagesLen = array[i].images ? array[i].images.length : 0;
        const imageArr = array[i].images

        for (let j = 0; j < imagesLen; j++) {

            let key = imageArr[j].imageKey
            const image = key ? await getSignedUrl(key) : ""
            imageArr[j]['image_url'] = image
            delete imageArr[j]['imageKey']
        }
    }

    return array
}
exports.getS3VariationsImages = getS3VariationsImages;
