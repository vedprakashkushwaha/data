// All handler functions related to encrypt Password
const encryptPasswordHandler = {};
const bcrypt = require('bcrypt');
const appConstants = require('../config/appConstants.json')

// encrypt the creator password
encryptPasswordHandler.encrypt = async (creatorPswd) => {
	const encrptPswd = await bcrypt.hash(creatorPswd, appConstants.SALTROUND)

	return encrptPswd
};

// decrypt the creator password
encryptPasswordHandler.decrypt = async (creatorPswd, hashPassword) => {
	const decrptPswd = await bcrypt.compare(creatorPswd, hashPassword)

	return decrptPswd
};

module.exports = encryptPasswordHandler;