const mongoose = require("mongoose");
const MetadataModel = mongoose.model("imageMetadata");
const ImageKeysModel = mongoose.model("imageBatchKey");
const responses = require("../config/responses");
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const requestParamsHandler = require('../handlers/requestParams');
const requestParams = require('../config/requestParams.json');
const appConstants = require('../config/appConstants.json');
const { getS3Images,uploadImageToS3 } = require('../handlers/commonHandler');
const { LexModelBuildingService } = require("aws-sdk");
const { response } = require("express");

module.exports.getImages = async function (req, res) {
    try {
        const bodyKeys = Object.keys(req.query);
        let paramKeys = Object.keys(req.params);
        paramKeys = [...paramKeys, ...bodyKeys]
        await requestParamsHandler.validateVariationType(paramKeys, requestParams.getImages);


        let data, image_batch_id, image_id;
        if (req.params.image_id) {
            image_id = req.params.image_id.replace(":", "");
        }
        if (req.query.image_batch_id) {
            image_batch_id = req.query.image_batch_id.replace(":", "");
        }

        if (image_id) {
            data = await ImageKeysModel.find({ _id: image_id })
                .select("imageBatch_id name imageKey num_editions")
                .populate("metadata","-_id -imageBatch_id -__v -createdAt").lean();
        } else {
            const offset = req.query.offset ? parseInt(req.query.offset) : 0;
            const max_entries = req.query.max_entries ? parseInt(req.query.max_entries) : 100;

            data = await ImageKeysModel.find({ imageBatch_id: image_batch_id })
                .skip(offset)
                .limit(max_entries)
                .populate("metadata", "-_id -imageBatch_id -__v -createdAt")
                .select("imageBatch_id name imageKey num_editions").lean();
        }
        if (data && data.length) {
            newData = await getS3Images(data)
            return responses.actionCompleteResponse(res, successMessages.foundMessage, { images: newData });
        } else {
            return responses.noDataFound(res, errorMessages.dataNotFound, []);
        }

    } catch (err) {
        console.log("Err :", err);
        return responses.sendError(res, err);
    }
}


module.exports.deleteImage = async function (req, res) {
    try {
        const paramKeys = Object.keys(req.params);
        await requestParamsHandler.validate(paramKeys, requestParams.deleteImage);

        const image_id = req.params.image_id.replace(":", "")

        const checkImage = await ImageKeysModel.findOne({ _id: image_id })
        if (!checkImage) throw new Error(errorMessages.imageNotFount);

        await MetadataModel.deleteOne({ _id: checkImage.metadata })

        ImageKeysModel.deleteOne({ _id: image_id }, function (err) {
            if (!err) {
                return responses.actionCompleteResponse(res, successMessages.deleteMessage, {});
            }
            else {
                return responses.sendError(res, err);
            }
        });

    } catch (err) {
        console.log("err: ", err)
        return responses.sendError(res, err);
    }
}

module.exports.createCollectibleImage = async function (req, res) {
    try {
        const bodydata = Object.keys(req.body);
        await requestParamsHandler.validate(bodydata, requestParams.createImage);

        let { image_batch_id, metadata, num_editions } = req.body;
        metadata.imageBatch_id = image_batch_id;
        num_editions = parseInt(num_editions, 10)
        const metadataCollection = await MetadataModel.create(metadata);
        let image = await ImageKeysModel.create({ imageBatch_id: image_batch_id, metadata: metadataCollection._id, num_editions: num_editions });
        return responses.actionCompleteResponse(res, successMessages.imageCreated, image._id, appConstants.CREATED_STATUS_CODE);
    } catch (err) {
        console.log("error:", err)
        return responses.sendError(res, err);
    }
}

module.exports.updateImageInfo = async function (req, res) {
    try {
        let paramKeys = Object.keys(req.params);
        let metadata, num_editions

        await requestParamsHandler.validate(paramKeys, requestParams.updateImageInfo);
        const param_Image_id = req.params.image_id.replace(":", "");
        let imageInfo = await ImageKeysModel.findById(param_Image_id);
        
        if (!imageInfo) {
            return responses.sendError(res, errorMessages.imageNotFount);
        }

        if (req.body.num_editions) {
            num_editions = parseInt(req.body.num_editions, 10)
            imageInfo = await ImageKeysModel.updateOne({ _id: param_Image_id }, { $set: { num_editions: num_editions } });
        }

        if (req.body.metadata) {
            metadata = req.body.metadata
            await MetadataModel.updateOne({ _id: imageInfo.metadata }, {metadata});
        }
        return responses.actionCompleteResponse(res, successMessages.imageInfoUpdated, appConstants.DEFAULT_SUCCESS_STATUS);

    } catch (err) {
        console.log("error:", err)
        return responses.sendError(res, err);

    }
}

module.exports.updateImage = async function (req, res) {
    try {
        let paramsKey = Object.keys(req.params);
        await requestParamsHandler.validate(paramsKey, requestParams.updateImage);
        const paramsImageKey = req.params.image_id.replace(":", "");

        let imageInfo = await ImageKeysModel.findById(paramsImageKey);
        if (!imageInfo) {
            return responses.sendError(res, errorMessages.imageNotFount);
        }

        const result = req.file ? await uploadImageToS3(req.file) : {};
        await ImageKeysModel.updateOne({ _id: paramsImageKey }, { $set: { imageKey: result.key } });
        return responses.actionCompleteResponse(res, successMessages.imageUpdated, appConstants.DEFAULT_SUCCESS_STATUS)

    } catch (err) {
        console.log("error:", err)
        return responses.sendError(res, err);
    }
}

// module.exports.getCollectibleImage = async function(req,res) {
// try {
//     const bodydata = Object.keys(req.body);
//     await requestParamsHandler.validate(bodydata, requestParams.)

// } catch (err) {
//     console.log("error:",err)
//     return responses.sendError(res,err);
// }
// }