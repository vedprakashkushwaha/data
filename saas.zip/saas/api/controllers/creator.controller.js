const mongoose = require('mongoose');
const Creator = mongoose.model('creator');
const responses = require('../config/responses');
const getToken = require('../../auth/getToken');
const { OAuth2Client } = require('google-auth-library');
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const Collection = mongoose.model('collection');
const appConstants = require('../config/appConstants.json');
const requestParams = require('../config/requestParams.json');
const requestParamsHandler = require('../handlers/requestParams');

module.exports.googleLogin = async function (req, res) {
	try {
		const CLIENT_ID = process.env.GOOGLE_CLIENT_ID

		const client = new OAuth2Client(CLIENT_ID);
		async function verify() {
			const ticket = await client.verifyIdToken({
				idToken: req.body.idToken,
				audience: CLIENT_ID,
			});
			const payload = ticket.getPayload();
			return payload;
		}
		const data = await verify();
		const values = {
			firstName: data['name'].split(" ")[0],
			lastName: data['name'].split(" ")[1],
			email: data['email'],
			googleId: data['sub'],
			isVerified: true,
		}

		let statusCode = appConstants.DEFAULT_SUCCESS_STATUS;
		let creator = await Creator.findOne({ email: data['email'] }).lean()
		if (creator) {
			values["updatedAt"] = new Date();
			await Creator.updateOne({ email: data['email'] }, { $set: values })
			creator = await Creator.findOne({ email: data['email'] }).lean()
		} else {
			creator = await Creator.create(values)
			statusCode = appConstants.CREATED_STATUS_CODE
		}
		const token = getToken({ creator_id: creator._id })
		let response = [{ creator_id: creator._id, firstName: creator.firstName, lastName: creator.lastName, token: token }]
		return responses.actionCompleteResponse(res, "", response, statusCode);

	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}


module.exports.getCreatorDetail = async function (req, res) {
	try {
		let data = await Creator.findOne({ _id: req.creator_id }).select('_id email')
		data = { creator_id: data._id, human_readable_id: data.email }
		return responses.actionCompleteResponse(res, successMessages.creatorFound, data);

	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.getCreatorDetailById = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.creatorById);

		let data = await Creator.findOne({ email_id: req.param.human_readable_id }).select('_id email')
		data = { creator_id: data._id, human_readable_id: data.email }
		return responses.actionCompleteResponse(res, successMessages.creatorFound, data);

	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

// module.exports.searchCreatorForCollab = async function (req, res) {
// 	try {
// 		const collection = await Collection.findOne({ _id: req.query.collectionId }).select('collaborators')
// 		let data;
// 		let DataFilter = {};
// 		if (req.query.email) {
// 			DataFilter['email'] = { '$regex': new RegExp("" + req.query.email, "i") }
// 			DataFilter['_id'] = { $ne: req.creator_id }

// 			data = await creator.find(DataFilter).lean().select('_id email')
// 			for (let i = 0; i < data.length; i++) {
// 				if (collection.collaborators.includes(data[i]._id)) {
// 					data.splice(i, 1);
// 				}
// 			}
// 		} else {
// 			return responses.noDataFound(res, errorMessages.emailRequired, []);
// 		}
// 		if (data && data.length) {
// 			return responses.actionCompleteResponse(res, successMessages.creatorFound, data);
// 		} else {
// 			return responses.noDataFound(res, errorMessages.dataNotFound, []);
// 		}
// 	} catch (err) {
// 		console.log("err: ", err)
// 		return responses.sendError(res, err);
// 	}
// }


module.exports.deleteCreator = async function (req, res) {
	try {
		const creator_id = req.creator_id
		const checkCreator = await Creator.findOne({ _id: creator_id })
		if (!checkCreator) return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);

		await creator.deleteOne({ _id: creator_id })

		return responses.actionCompleteResponse(res, successMessages.creatorFound, data);

	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}
