const mongoose = require('mongoose');
const NFTLayer = mongoose.model('nftlayer');
const NFTLayerVariant = mongoose.model('nftlayervariant');
const responses = require('../config/responses');
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const requestParamsHandler = require('../handlers/requestParams');
const requestParams = require('../config/requestParams.json');
const appConstants = require('../config/appConstants.json');
const { uploadImageToS3, getS3VariationsImages } = require('../handlers/commonHandler')
const Collection = mongoose.model('collection');

module.exports.create = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.body);
		await requestParamsHandler.validate(paramKeys, requestParams.createVariant);

		let nftvariant = await NFTLayerVariant.findOne({ name: req.body.name }).lean()
		if (nftvariant) {
			return responses.actionCompleteResponse(res, errorMessages.duplicateVariant, nftvariant, appConstants.ALREADY_EXIST);
		} else {
			let nftLayer = await NFTLayer.findOne({ _id: req.body.layer_id, creator_id: req.creator_id }).lean();

			if (nftLayer) {
				let collection = await Collection.findOne({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: nftLayer.collection_id }).lean();
				if (!collection) {
					return responses.sendError(res, errorMessages.invalidRequest, [], appConstants.UNAUTHORIZED_STATUS_CODE);
				}
				const highest_id = await NFTLayerVariant.findOne({layer_id: req.body.layer_id}).sort({numeric_id:-1}).limit(1);
console.log(highest_id);
				const intialImages = [{ type: "Standalone", imageKey: "" }, { type: "Combined", imageKey: "" }]
				const data = {
					numeric_id: highest_id.numeric_id ? highest_id.numeric_id + 1 : 1,
					name: req.body.name,
					images: intialImages, 		// Default empty images
					layer_id: req.body.layer_id,
					rarity: req.body.rarity,
					form_nft_when_detached: req.body.form_nft_when_detached
				};
				nftvariant = await NFTLayerVariant.create(data);
				return responses.actionCompleteResponse(res, successMessages.variantCreated, { variation_id: nftvariant._id });
			} else {
				return responses.actionCompleteResponse(res, errorMessages.invalidNFT, {});
			}
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.getVariations = async function (req, res) {
	try {
		var variation_id = req.params.variation_id ? req.params.variation_id.replace(":", "") : null

		var data = [];
		if (variation_id) {
			data = await NFTLayerVariant.find({ _id: variation_id }).lean()
		} else {
			data = await NFTLayerVariant.find({ layer_id: req.query.layer_id }).lean()
		}
		if (data && data.length) {
			data = await getS3VariationsImages(data)
			return responses.actionCompleteResponse(res, successMessages.variantFound, { variations: data });
		} else {
			return responses.noDataFound(res, errorMessages.dataNotFound, []);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.updateVariant = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.updateVariant);

		const variation_id = req.params.variation_id.replace(":", "")
		let nftvariant = await NFTLayerVariant.findOne({ _id: variation_id }).lean()
		if (!nftvariant) {
			return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		}
		const data = {}
		// if (req.file) {
		// 	const result = await uploadImageToS3(req.file);
		// 	data.imageKey = result.key;
		// }
		if (req.body.name) {
			data.name = req.body.name;
		}
		if (req.body.rarity) {
			data.rarity = req.body.rarity;
		}
		if (req.body.form_nft_when_detached) {
			data.form_nft_when_detached = req.body.form_nft_when_detached;
		}
		let collection = await NFTLayerVariant.updateOne({ _id: variation_id }, data);
		if (collection) {
			return responses.actionCompleteResponse(res, successMessages.variantUpdated, {});
		} else {
			return responses.sendError(res, errorMessages.unableToUpdateVariant, {});
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.deleteVariant = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.removeVariant);

		const variation_id = req.params.variation_id.replace(":", "")
		let nftvariant = await NFTLayerVariant.findOne({ _id: variation_id }).lean()
		if (!nftvariant) {
			return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		}

		NFTLayerVariant.deleteOne({ _id: variation_id }, function (err) {
			if (!err) {
				return responses.actionCompleteResponse(res, successMessages.variantRemoved, {});
			}
			else {
				return responses.sendError(res, errorMessages.unableToRemoveVariant);
			}
		});

	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}


module.exports.updateVariationImage = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.variationImage);

		const variation_id = req.params.variation_id.replace(":", "")
		const type = req.params.type.replace(":", "")
		await requestParamsHandler.validateVariationType([type], requestParams.variationImageType);

		let variant = await NFTLayerVariant.findOne({ _id: variation_id }).lean()
		if (!variant) {
			return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		}

		if (req.file) {
			const result = await uploadImageToS3(req.file);
			await NFTLayerVariant.updateOne({ _id: variation_id, "images.type": type }, { $set: { "images.$.imageKey": result.key } });
		} else {
			return responses.sendError(res, errorMessages.imageNotFount, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		}
		return responses.actionCompleteResponse(res, successMessages.variantUpdated, []);
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}