const mongoose = require('mongoose');
const Collection = mongoose.model('collection');
const responses = require('../config/responses');
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const requestParamsHandler = require('../handlers/requestParams');
const requestParams = require('../config/requestParams.json');
const Creator = mongoose.model('creator');
const { getS3Images, uploadImageToS3 } = require('../handlers/commonHandler')
const appConstants = require('../config/appConstants.json');

module.exports.create = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.body);
		await requestParamsHandler.validate(paramKeys, requestParams.createCollection);
		let collection = await Collection.findOne({ name: req.body.name, creator_id: req.creator_id }).lean()
		if (collection) {
			const collectionData = { collection_id: collection._id }
			
			return responses.actionCompleteResponse(res, errorMessages.duplicateCollection, collectionData, appConstants.ALREADY_EXIST);
		} else {
			const result = req.file ? await uploadImageToS3(req.file) : {};
			const data = {
				name: req.body.name,
				description: req.body.description,
				imageKey: result ? result.key : "",
				creator_id: req.creator_id,
				type: req.body.type,
				image_width: req.body.image_width,
				image_height: req.body.image_height
			};
			collection = await Collection.create(data);
			const collectionData = { collection_id: collection._id }
			return responses.actionCompleteResponse(res, successMessages.collectionCreated, collectionData, appConstants.CREATED_STATUS_CODE);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.getCollections = async function (req, res) {
	try {
		var collection_id = req.params.collection_id ? req.params.collection_id.replace(":", "") : null
		
		let collection = []
		if (collection_id) {
			collection = await Collection.find({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: collection_id }).populate({ path: "collaborators", select: "_id firstName lastName email" }).lean()
		} else {
			collection = await Collection.find({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }] }).populate({ path: "collaborators", select: "_id firstName lastName email" }).lean()
		}
		
		if (collection && collection.length) {
			collection = await getS3Images(collection)
			return responses.actionCompleteResponse(res, successMessages.collectionFound, collection);
		} else {
			return responses.noDataFound(res, errorMessages.dataNotFound, []);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.updateCollection = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.updateCollections);
		const collection_id = req.params.collection_id.replace(":", "")
		
		let collection = await Collection.findOne({ _id: { $nin: [collection_id] }, name: req.body.name, $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }] }).lean()
		if (collection) {
			return responses.actionCompleteResponse(res, errorMessages.alreadyAvailable, collection, appConstants.ALREADY_EXIST);
		}
		
		let checkCollection = await Collection.findOne({ _id: collection_id }).lean()
		if (!checkCollection) {
			return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		}
		const data = {}
		if (req.file) {
			const result = await uploadImageToS3(req.file);
			// data.image = result.Location;
			data.imageKey = result.key;
		}
		if (req.body.name) {
			data.name = req.body.name;
		} if (req.body.description) {
			data.description = req.body.description;
		} if (req.body.image_width) {
			data.image_width = req.body.image_width;
		} if (req.body.image_height) {
			data.image_height = req.body.image_height;
		}
		
		await Collection.updateOne({ _id: collection_id }, data);
		
		const updatedVal = await Collection.findOne({ _id: collection_id })
		.select("name description collaborators type -_id")
		.populate({ path: 'collaborators', select: "_id" });
		
		return responses.actionCompleteResponse(res, successMessages.collectionUpdated, updatedVal);
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.deleteCollection = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.removeCollection);
		
		const collection_id = req.params.collection_id.replace(":", "")
		
		const checkCollection = await Collection.findOne({ _id: collection_id })
		if (!checkCollection) throw new Error(errorMessages.collectionNotFound);
		
		Collection.deleteOne({ _id: collection_id }, function (err) {
			if (!err) {
				return responses.actionCompleteResponse(res, successMessages.collectionRemoved, {});
			}
			else {
				return responses.sendError(res, errorMessages.unableToRemoveCollection);
			}
		});
		
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.addCollaborator = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.body);
		await requestParamsHandler.validate(paramKeys, requestParams.addCollaborator);
		
		const checkCollection = await Collection.findOne({ _id: req.body.collection_id })
		if (!checkCollection) throw new Error(errorMessages.collectionNotFound);
		
		const checkCreator = await Creator.findOne({ email: req.body.email })
		if (!checkCreator) throw new Error(errorMessages.creatorNotFound);
		if ((checkCreator._id).toString() === req.creator_id) throw new Error(errorMessages.unableToAddCollaborator);
		
		const checkCollaborator = await Collection.findOne({ _id: req.body.collection_id, collaborators: checkCreator._id })
		if (checkCollaborator) return responses.sendError(res, errorMessages.alreadyExist, [], appConstants.ALREADY_EXIST);
		
		Collection.findOneAndUpdate({ _id: req.body.collection_id }, { $push: { collaborators: checkCreator._id } },
			function (error, success) {
				if (error) {
					console.log(error);
					return responses.sendError(res, errorMessages.unableToAddCollaborator);
				} else {
					console.log(success);
					return responses.actionCompleteResponse(res, successMessages.collaboratorAdded, {});
				}
			}
			);
		} catch (err) {
			console.log("err: ", err)
			return responses.sendError(res, err);
		}
	}
	
	module.exports.removeCollaborator = async function (req, res) {
		try {
			const bodyKeys = Object.keys(req.query);
			let paramKeys = Object.keys(req.params);
			paramKeys = [...paramKeys, ...bodyKeys]
			
			await requestParamsHandler.validate(paramKeys, requestParams.removeCollaborator);
			
			const collection_id = req.params.collection_id.replace(":", "")
			
			const check = await Collection.findOne({ _id: collection_id, collaborators: req.query.creator_id }).lean()
			
			if (!check) {
				return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
			}
			Collection.findOneAndUpdate({ _id: collection_id }, { $pull: { collaborators: req.query.creator_id } },
				function (error, success) {
					if (error) {
						console.log(error);
						return responses.sendError(res, errorMessages.unableToRemoveCollaborator);
					} else {
						return responses.actionCompleteResponse(res, successMessages.collaboratorRemoved, []);
					}
				}
				);
			} catch (err) {
				console.log("err: ", err)
				return responses.sendError(res, err);
			}
		}
		
		
		module.exports.upload = async function (req, res) {
			try {
				const paramKeys = Object.keys(req.body);
				
			} catch (err) {
				console.log("err: ", err)
				return responses.sendError(res, err);
			}
		}