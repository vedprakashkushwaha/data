const mongoose = require("mongoose")
const ImageBatch = mongoose.model("imageBatch")
const CollectionModel = mongoose.model("collection")
const responses = require("../config/responses")
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const requestParamsHandler = require('../handlers/requestParams');
const requestParams = require('../config/requestParams.json');
const appConstants = require('../config/appConstants.json');
const cacheHandler = require('../../imageGenerationService/handlers/cache');

module.exports.createBatch = async function (req, res) {
    try {
        const paramKeys = Object.keys(req.body);
        await requestParamsHandler.validate(paramKeys, requestParams.createBatch);

        const { collection_id, name } = req.body

        const check = await ImageBatch.findOne({ collection_id: collection_id, name: name }).lean()
        if (check) {
            const data = { image_batch_id: check._id }
            return responses.actionCompleteResponse(res, errorMessages.duplicateMessage, data, appConstants.ALREADY_EXIST);
        }

        const batch = await ImageBatch.create({ collection_id: collection_id, name: name })

        const data = { image_batch_id: batch._id }
        return responses.actionCompleteResponse(res, successMessages.createdMessage, data, appConstants.CREATED_STATUS_CODE);

    } catch (err) {
        console.log("Err :", err)
        return responses.sendError(res, err)
    }
}

module.exports.getBatches = async function (req, res) {
    try {
        const bodyKeys = Object.keys(req.query);
        let paramKeys = Object.keys(req.params);
        paramKeys = [...paramKeys, ...bodyKeys]
        await requestParamsHandler.validateVariationType(paramKeys, requestParams.getImageBatches);

        let batchData, image_batch_id, collection_id;
        if (req.params.image_batch_id) {
            image_batch_id = req.params.image_batch_id.replace(":", "");
        }
        if (req.query.collection_id) {
            collection_id = req.query.collection_id.replace(":", "");
        }
        if (image_batch_id) {
            batchData = await ImageBatch.findOne({ _id: image_batch_id });
        } else {
            batchData = await ImageBatch.find({ collection_id: collection_id });
        }

        return responses.actionCompleteResponse(res, successMessages.foundMessage, batchData);

    } catch (err) {
        console.log("Err :", err);
        return responses.sendError(res, err);
    }
}

module.exports.deleteBatch = async function (req, res) {
    try {
        const paramKeys = Object.keys(req.params);
        await requestParamsHandler.validate(paramKeys, requestParams.deleteImageBatch);

        if (req.params.image_batch_id) {
            var image_batch_id = req.params.image_batch_id.replace(":", "");
        }
        const check = await ImageBatch.findOne({ _id: image_batch_id }).lean()
        if (!check) {
            return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
        }

        await ImageBatch.deleteOne({ _id: image_batch_id })

        return responses.actionCompleteResponse(res, successMessages.deleteMessage);

    } catch (err) {
        console.log("Err :", err)
        return responses.sendError(res, err)
    }
}


module.exports.updateImageBatch = async function (req, res) {
    try {
        const paramKeys = Object.keys(req.body);
        await requestParamsHandler.validate(paramKeys, requestParams.updateImageBatch);
        const image_batch_id = req.params.image_batch_id.replace(":", "");

        let checkImageBatch = await ImageBatch.findOne({ _id: image_batch_id }).lean();
        if (!checkImageBatch) {
            return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
        }
        let collection = await CollectionModel.aggregate([
            {
                $match: {
                    _id: mongoose.Types.ObjectId(checkImageBatch.collection_id),
                    $or: [{ creator_id: mongoose.Types.ObjectId(req.creator_id) },
                    { collaborators: mongoose.Types.ObjectId(req.creator_id) }]
                }
            },
            {
                $lookup: {
                    from: "imageBatch",
                    localField: "_id",
                    foreignField: "collection_id",
                    as: "imageBatch"
                }
            },
            { $limit: 1 }
        ]);
        if (!collection) {
            return responses.sendError(res, errorMessages.invalidRequest, collection, appConstants.UNAUTHORIZED_STATUS_CODE);
        }

        const data = {}
        if (req.body.name) {
            data.name = req.body.name;
        }

        await ImageBatch.updateOne({ _id: image_batch_id }, data);

        return responses.actionCompleteResponse(res, successMessages.updateMessage);
    } catch (err) {
        console.log("err: ", err)
        return responses.sendError(res, err);
    }
}


module.exports.generateImage = async function (req, res) {
    try {
        const bodyKeys = Object.keys(req.body);
        let paramKeys = Object.keys(req.params);
        paramKeys = [...paramKeys, ...bodyKeys]
        await requestParamsHandler.validate(paramKeys, requestParams.generateImage);

        let image_batch_id = req.params.image_batch_id;
        if (image_batch_id) {
            image_batch_id = req.params.image_batch_id.replace(":", "");
        }
        cacheHandler.setData(image_batch_id, JSON.stringify({progress: 0}));
        const { number, name_prefix, numbering_offset } = req.body;

        const check = await ImageBatch.findOne({ _id: image_batch_id }).lean()
        if (!check) {
            return responses.actionCompleteResponse(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
        }

        const batchData = {
            number: number,
            name_prefix: name_prefix,
            numbering_offset: numbering_offset,
            status: "initiated",
            updatedAt: new Date()
        };

        let batch = await ImageBatch.updateOne({ _id: image_batch_id }, { $set: batchData });

        const data = { image_batch_id: image_batch_id }

        return responses.actionCompleteResponse(res, successMessages.imageGenerationSetup, data, appConstants.CREATED_STATUS_CODE);

    } catch (err) {
        console.log("Err :", err)
        return responses.sendError(res, err)
    }
}


module.exports.imageGenerationStatus = async function (req, res) {
    try {
        let paramKeys = Object.keys(req.params);
        await requestParamsHandler.validate(paramKeys, requestParams.generationStatus);
        const status = await cacheHandler.getData(req.params.image_batch_id);
        return responses.actionCompleteResponse(res, successMessages.generationStatus, status, appConstants.DEFAULT_SUCCESS_STATUS);
    } catch (err) {
        console.log("Err :", err)
        return responses.sendError(res, err)
    }
}