const mongoose = require('mongoose');
const NFTLayer = mongoose.model('nftlayer');
const responses = require('../config/responses');
const successMessages = require('../config/successMessages.json');
const errorMessages = require('../config/errorMessages.json');
const requestParamsHandler = require('../handlers/requestParams');
const requestParams = require('../config/requestParams.json');
const Collection = mongoose.model('collection');
const { getS3Images, uploadImageToS3 } = require('../handlers/commonHandler')
const appConstants = require('../config/appConstants.json');

module.exports.create = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.body);
		await requestParamsHandler.validate(paramKeys, requestParams.createLayer);
		// if (!req.file) throw new Error(errorMessages.imageRequired);
		
		let nft = await NFTLayer.findOne({ name: req.body.name, creator_id: req.creator_id }).lean()
		if (nft) {
			let response = { layer_id: nft._id }
			return responses.actionCompleteResponse(res, errorMessages.duplicateLayer, response, appConstants.ALREADY_EXIST);
		} else {
			let collection = await Collection.findOne({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: req.body.collection_id }).lean();
			if (collection) {
				const highest_id = await NFTLayer.findOne({collection_id: req.body.collection_id}).sort({numeric_id:-1}).limit(1);
				
				const data = {
					numeric_id: highest_id.numeric_id ? highest_id.numeric_id + 1 : 1,
					name: req.body.name,
					// imageKey: result.key,
					collection_id: req.body.collection_id,
					form_nft_when_detached: req.body.form_nft_when_detached,
					order: req.body.order
				};
				nftLayer = await NFTLayer.create(data);
				let response = { layer_id: nftLayer._id }
				return responses.actionCompleteResponse(res, successMessages.layerCreated, response, appConstants.CREATED_STATUS_CODE);
			} else {
				return responses.sendError(res, errorMessages.invalidRequest, [], appConstants.UNAUTHORIZED_STATUS_CODE);
			}
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}


module.exports.getLayers = async function (req, res) {
	try {
		var layer_id = req.params.layer_id ? req.params.layer_id.replace(":", "") : null
		
		var data = [];
		if (layer_id) {
			data = await NFTLayer.find({ _id: layer_id }).select('_id name imageKey form_nft_when_detached order').lean()
		} else {
			data = await NFTLayer.find({ collection_id: req.query.collection_id }).select('_id name imageKey form_nft_when_detached order').lean()
		}
		
		if (data && data.length) {
			data = await getS3Images(data)
			return responses.actionCompleteResponse(res, successMessages.layerFound, { layers: data });
		} else {
			return responses.noDataFound(res, errorMessages.dataNotFound, []);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}


module.exports.updateLayer = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.updateLayer);
		
		const layer_id = req.params.layer_id.replace(":", "")
		
		
		let layer = await NFTLayer.findOne({ _id: layer_id });
		if (!layer) return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		else {
			const validCreator = await Collection.findOne({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: layer.collection_id }).lean()
			if (!validCreator) {
				return responses.sendError(res, errorMessages.invalidRequest, [], appConstants.UNAUTHORIZED_STATUS_CODE);
			}
		}
		
		const data = {}
		if (req.body.name) {
			data.name = req.body.name;
		} if (req.body.form_nft_when_detached) {
			data.form_nft_when_detached = req.body.form_nft_when_detached
		} if (req.body.order) {
			data.order = req.body.order
		}
		
		let collection = await NFTLayer.updateOne({ _id: layer_id }, data);
		
		if (collection) {
			return responses.actionCompleteResponse(res, successMessages.layerUpdated, []);
		} else {
			return responses.sendError(res, errorMessages.unableToUpdateLayer, []);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}

module.exports.deleteLayer = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.removeLayer);
		
		const layer_id = req.params.layer_id.replace(":", "")
		
		let layer = await NFTLayer.findOne({ _id: layer_id });
		if (!layer) return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		else {
			const validCreator = await Collection.findOne({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: layer.collection_id }).lean()
			if (!validCreator) {
				return responses.sendError(res, errorMessages.invalidRequest, [], appConstants.UNAUTHORIZED_STATUS_CODE);
			}
		}
		NFTLayer.deleteOne({ _id: layer_id }, function (err) {
			if (!err) {
				return responses.actionCompleteResponse(res, successMessages.layerRemoved, {});
			}
			else {
				return responses.sendError(res, errorMessages.unableToRemoveLayer);
			}
		});
		
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}


module.exports.updateLayerImage = async function (req, res) {
	try {
		const paramKeys = Object.keys(req.params);
		await requestParamsHandler.validate(paramKeys, requestParams.updateLayer);
		
		const layer_id = req.params.layer_id.replace(":", "")
		
		
		let layer = await NFTLayer.findOne({ _id: layer_id });
		if (!layer) return responses.sendError(res, errorMessages.dataNotFound, [], appConstants.NO_DATA_FOUND_STATUS_CODE);
		else {
			const validCreator = await Collection.findOne({ $or: [{ creator_id: req.creator_id }, { collaborators: req.creator_id }], _id: layer.collection_id }).lean()
			if (!validCreator) {
				return responses.sendError(res, errorMessages.invalidRequest, [], appConstants.UNAUTHORIZED_STATUS_CODE);
			}
		}
		
		const data = {}
		if (req.file) {
			const result = await uploadImageToS3(req.file);
			data.imageKey = result.key;
		}
		
		let collection = await NFTLayer.updateOne({ _id: layer_id }, data);
		
		if (collection) {
			return responses.actionCompleteResponse(res, successMessages.layerUpdated, []);
		} else {
			return responses.sendError(res, errorMessages.unableToUpdateLayer, []);
		}
	} catch (err) {
		console.log("err: ", err)
		return responses.sendError(res, err);
	}
}