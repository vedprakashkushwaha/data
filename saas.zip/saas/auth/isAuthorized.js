const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const secret = process.env.TOKENSECRET
const responses = require('../api/config/responses');
const appConstants = require('../api/config/appConstants.json');
const Creator = mongoose.model('creator');

module.exports = async (req, res, next) => {
  try {
    if (!req.headers.authorization.split(' ')[1]) {
      return responses.sendError(res, "JWT Token not available");
    }
    // const token = req.header("x-auth-token")
    const token = req.headers.authorization.split(' ')[1];
    const decodedToken = jwt.verify(token, secret);

    const checkValidCreator = await Creator.findOne({ _id: decodedToken.data.creator_id, isVerified: true })
    if (!checkValidCreator) {
      return responses.sendError(res, "Invalid token");
    } else {
      req.creator_id = decodedToken.data.creator_id
      req.loginType = req.header("X-Authorization-Method‌")

      next();
    }
  } catch {
    return responses.sendError(res, "Invalid token", "", appConstants.UNAUTHORIZED_STATUS_CODE);
  }
};