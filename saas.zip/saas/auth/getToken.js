const jwt = require('jsonwebtoken');
const appConstants = require('../api/config/appConstants.json')
const secret = process.env.TOKENSECRET
module.exports = (payload) => {
    try {
        const token = jwt.sign({ data: payload }, secret, {
            expiresIn: appConstants.JWT_TOKEN_EXPIRE_TIME
        });
        return token
    } catch (err) {
        console.log("err: ", err)
    }
};